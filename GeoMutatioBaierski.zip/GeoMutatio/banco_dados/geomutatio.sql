-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20-Nov-2019 às 01:15
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geomutatio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairro`
--

CREATE TABLE `bairro` (
  `nombairro` varchar(80) DEFAULT NULL,
  `idbairro` int(11) NOT NULL,
  `idcidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `nomcidade` varchar(80) DEFAULT NULL,
  `idcidade` int(11) NOT NULL,
  `iduf` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `familia`
--

CREATE TABLE `familia` (
  `nome_fam` varchar(30) DEFAULT NULL,
  `id_familia` int(10) NOT NULL,
  `pessoas_fam` varchar(255) DEFAULT NULL,
  `recursos_nec` varchar(255) NOT NULL,
  `telefone_fam` varchar(30) NOT NULL,
  `endereco_fam` varchar(255) NOT NULL,
  `foto_familia` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `familia`
--

INSERT INTO `familia` (`nome_fam`, `id_familia`, `pessoas_fam`, `recursos_nec`, `telefone_fam`, `endereco_fam`, `foto_familia`) VALUES
('Família Silva', 17, '2', '2', '', '', 0x7369616d65735f73756d6d65726e69676874732e6a7067);

-- --------------------------------------------------------

--
-- Estrutura da tabela `logradouro`
--

CREATE TABLE `logradouro` (
  `nomlogradouro` varchar(80) DEFAULT NULL,
  `cep` varchar(11) DEFAULT NULL,
  `idlogradouro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_bairro`
--

CREATE TABLE `log_bairro` (
  `idbairro` int(11) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticia`
--

CREATE TABLE `noticia` (
  `codnoticia` int(5) NOT NULL,
  `titulo_noticia` varchar(500) DEFAULT 'NULL',
  `subtitulo_noticia` varchar(1350) NOT NULL,
  `desc_noticia` mediumtext,
  `data_noticia` date DEFAULT NULL,
  `foto_noticia` text,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `noticia`
--

INSERT INTO `noticia` (`codnoticia`, `titulo_noticia`, `subtitulo_noticia`, `desc_noticia`, `data_noticia`, `foto_noticia`, `cpf`) VALUES
(23, 'Tufão Hagibis deixa aos menos 56 mortos e mais de 204 feridos no Japão', 'O Tufão Hagibis atingiu o Japão no último sábado e ao menos 17 pessoas estão desaparecidas', 'O Tufão Hagibis provocou no Japão precipitações recordes de chuva, deixando várias pessoas mortas e causando sérias destruições, inclusive de moradias. Pelo menos 56 pessoas morreram, 17 estão desaparecidas e 204 foram feridas.\r\n\r\nO Ministério dos Transportes, Infraestrutura e Turismo declarou que diques ao longo de 21 rios foram destruídos.\r\n\r\nNa província de Nagano, noroeste de Tóquio, um dique se rompeu no Rio Chikuma, causando inundação em ampla área. Muitas pessoas ficaram presas em suas casas. Helicópteros de socorro retiraram essas pessoas pelo telhado.\r\n\r\nUma mulher que foi socorrida disse: ” tudo em minha casa foi levado pela água, em frente de meus olhos. Foi uma noite de horror. Sou uma pessoa de sorte, porque continuo viva.”\r\n\r\nUma ponte em uma estrada de ferro caiu no rio, e as águas da tempestade prejudicaram os serviços ferroviários. Uma garagem de trens, da linha do trem-bala Hokuriku Shinkansen, foi inundada. A East Japan Railways, ou JR Leste, diz que dez trens, num total de 120 vagões, foram danificados.\r\n\r\nA tragédia chegou também à Província de Fukushima, onde uma mulher de aproximadamente 70 anos caiu durante uma operação de socorro por helicóptero e morreu O Departamento de Combate a Incêndios de Tóquio disse que o pessoal de socorro esqueceu de fixar dispositivo de segurança no corpo da vítima.\r\n\r\nEsforços de socorro continuam. A extensão total dos danos ainda não é conhecida. As pessoas estão sendo aconselhadas a permanecer cautelosas contra inundações de rios e ficar em alerta para enfrentar possíveis deslizamentos de terra.\r\n\r\nEnergia elétrica\r\nEm Tóquio e oito províncias do entorno, 55.800 residências ainda estavam sem energia elétrica nesta segunda-feira devido à passagem do tufão.\r\n\r\nA Companhia de Energia Elétrica de Tóquio (Tepco) trabalha para consertar instalações de transmissão danificadas por alagamentos. Em conjunto com o Ministério da Economia, Comércio e Indústria, a Tepco enviou geradores móveis para alguns hospitais e centros de evacuação.\r\n\r\nA empresa espera que a eletricidade seja restaurada até quarta-feira (16) em 90% das áreas afetadas. Ela pede que as pessoas desliguem os disjuntores, e alerta a todos para que não liguem aparelhos eletrônicos molhados.\r\n\r\n*Emissora pública de televisão do Japão', '2019-10-13', 'C2C-Deltaa4.jpg', '05158858942');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencia`
--

CREATE TABLE `ocorrencia` (
  `id_ocorrencia` int(10) NOT NULL,
  `nome_ocorrencia` varchar(70) NOT NULL,
  `qtd_curtidas` int(4) DEFAULT '0',
  `tipo_ocorrencia` varchar(50) DEFAULT NULL,
  `data_ocorrencia` date DEFAULT NULL,
  `local` varchar(255) NOT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `imagem_ocorrencia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ocorrencia`
--

INSERT INTO `ocorrencia` (`id_ocorrencia`, `nome_ocorrencia`, `qtd_curtidas`, `tipo_ocorrencia`, `data_ocorrencia`, `local`, `cpf`, `imagem_ocorrencia`) VALUES
(13, 'Alagamento', 0, 'alagamento', '2019-10-16', '-26.296443, -48.84573', '05158858942', 'alagamento.png'),
(14, 'Buraco', 0, 'buraco', '2019-10-16', '-26.293818, -48.863395', '05158858942', 'buraco.png'),
(15, 'Deslizamento de Terra', 0, 'deslizamento', '2019-10-16', '-26.292197, -48.853819', '05158858942', 'deslizamento.png'),
(16, 'Buraco', 0, 'buraco', '2019-10-16', '-26.282157, -48.810625', '05158858942', 'buraco.png'),
(17, 'Deslizamento de Terra', 0, 'deslizamento', '2019-10-16', '-26.272691, -48.878088', '05158858942', 'deslizamento.png'),
(18, 'Alagamento', 0, 'alagamento', '2019-10-16', '-26.324607, -48.841782', '05158858942', 'alagamento.png'),
(19, 'Alagamento', 0, 'alagamento', '2019-10-16', '-26.304355, -48.815517', '05158858942', 'alagamento.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipuser`
--

CREATE TABLE `tipuser` (
  `desctipuser` varchar(80) DEFAULT NULL,
  `idtipuser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipuser`
--

INSERT INTO `tipuser` (`desctipuser`, `idtipuser`) VALUES
('Usuário Comum', 0),
('Administrador', 1),
('Autor', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `uf`
--

CREATE TABLE `uf` (
  `iduf` int(11) NOT NULL,
  `nomuf` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_tipuser`
--

CREATE TABLE `user_tipuser` (
  `cpf` varchar(14) DEFAULT NULL,
  `idtipuser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `cpf` varchar(14) NOT NULL,
  `tipuser` tinyint(1) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `senha` varchar(14) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nome`, `email`, `cpf`, `tipuser`, `datanasc`, `senha`, `idlogradouro`) VALUES
('Administrador', 'admin@admin.com', '05158858942', 1, '2001-10-06', 'admin', NULL),
('Autor', 'autor@autor.com', '14236987412', 2, '1988-05-02', 'autor', NULL),
('Usuario Comum', 'usuario@usuario.com', '23412412434', 0, '2001-05-26', 'usuario', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bairro`
--
ALTER TABLE `bairro`
  ADD PRIMARY KEY (`idbairro`),
  ADD KEY `idcidade` (`idcidade`);

--
-- Indexes for table `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`idcidade`),
  ADD KEY `iduf` (`iduf`);

--
-- Indexes for table `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`id_familia`);

--
-- Indexes for table `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`idlogradouro`);

--
-- Indexes for table `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD KEY `idbairro` (`idbairro`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Indexes for table `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`codnoticia`) USING BTREE,
  ADD UNIQUE KEY `codnoticia` (`codnoticia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD PRIMARY KEY (`id_ocorrencia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `tipuser`
--
ALTER TABLE `tipuser`
  ADD PRIMARY KEY (`idtipuser`);

--
-- Indexes for table `uf`
--
ALTER TABLE `uf`
  ADD PRIMARY KEY (`iduf`);

--
-- Indexes for table `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD KEY `cpf` (`cpf`),
  ADD KEY `idtipuser` (`idtipuser`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `familia`
--
ALTER TABLE `familia`
  MODIFY `id_familia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `noticia`
--
ALTER TABLE `noticia`
  MODIFY `codnoticia` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  MODIFY `id_ocorrencia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `bairro`
--
ALTER TABLE `bairro`
  ADD CONSTRAINT `bairro_ibfk_1` FOREIGN KEY (`idcidade`) REFERENCES `cidade` (`idcidade`);

--
-- Limitadores para a tabela `cidade`
--
ALTER TABLE `cidade`
  ADD CONSTRAINT `cidade_ibfk_1` FOREIGN KEY (`iduf`) REFERENCES `uf` (`iduf`);

--
-- Limitadores para a tabela `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD CONSTRAINT `log_bairro_ibfk_1` FOREIGN KEY (`idbairro`) REFERENCES `bairro` (`idbairro`),
  ADD CONSTRAINT `log_bairro_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD CONSTRAINT `ocorrencia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD CONSTRAINT `user_tipuser_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`),
  ADD CONSTRAINT `user_tipuser_ibfk_2` FOREIGN KEY (`idtipuser`) REFERENCES `tipuser` (`idtipuser`);

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
