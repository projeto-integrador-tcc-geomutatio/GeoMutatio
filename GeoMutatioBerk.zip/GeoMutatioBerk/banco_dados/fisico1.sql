-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20-Jun-2019 às 21:02
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geomutatio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

CREATE TABLE `endereco` (
  `cep` varchar(8) NOT NULL,
  `nome_logradouro` varchar(150) DEFAULT NULL,
  `nome_bairro` varchar(50) DEFAULT NULL,
  `nome_cidade` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticia`
--

CREATE TABLE `noticia` (
  `codnoticia` varchar(5) NOT NULL,
  `titulo_noticia` varchar(50) DEFAULT NULL,
  `hora_noticia` varchar(5) DEFAULT NULL,
  `desc_noticia` varchar(1350) DEFAULT NULL,
  `data_noticia` date DEFAULT NULL,
  `cpf_noticia` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `not_end`
--

CREATE TABLE `not_end` (
  `codnoticia` varchar(5) DEFAULT NULL,
  `cep_noticia` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencia`
--

CREATE TABLE `ocorrencia` (
  `codocorrencia` varchar(5) NOT NULL,
  `titulo_ocorrencia` varchar(50) DEFAULT NULL,
  `hora_ocorrencia` varchar(5) DEFAULT NULL,
  `desc_ocorrencia` varchar(1350) DEFAULT NULL,
  `data_ocorrencia` date DEFAULT NULL,
  `cpf_ocorrencia` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `oc_end`
--

CREATE TABLE `oc_end` (
  `codocorrencia` varchar(5) DEFAULT NULL,
  `cep_ocorrencia` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipuser`
--

CREATE TABLE `tipuser` (
  `desctipuser` varchar(80) DEFAULT NULL,
  `idtipuser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_tipuser`
--

CREATE TABLE `user_tipuser` (
  `cpf` varchar(14) DEFAULT NULL,
  `idtipuser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `cpf` varchar(14) NOT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `tipuser` tinyint(1) DEFAULT '0',
  `datanasc` date DEFAULT NULL,
  `senha` varchar(14) DEFAULT NULL,
  `cep_usuario` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`cpf`, `nome`, `email`, `tipuser`, `datanasc`, `senha`, `cep_usuario`) VALUES
('1246987426', 'Bryan Pedro Henrique Cavalcanti', 'bbryancavalcanti@iaru.com.br', 0, '1998-10-14', 'bryan123', NULL),
('1248975638', 'Pedro Henrique Cláudio Fogaça', 'pedrohenrique@paae.com.br', 0, '1972-11-24', 'Gu9w2ISf', NULL),
('1423698741', 'João Victor Fernando Cavalcanti', 'jjoaocavalcanti@tkk.com.br', 0, '1988-05-02', '4BrJsJC', NULL),
('1653248769', 'Márcio Rafael Rezende', 'mmarciorafaelrezende@ig.com', 0, '1982-07-29', 'WhJeayxBfOS', NULL),
('1958742358', 'Tânia Tatiane Alessandra Ramos', 'taniatatiane@startingfitness.com.br', 0, '1948-12-08', 'QZpHV5c1wZN', NULL),
('2341241241', 'Mateus Roberto Galvão', 'mmateusgalvao@lexos.com.br', 0, '2001-05-26', 'vdnHsYFeCqB', NULL),
('4125162316', 'Raquel Tatiane Vera da Luz', 'raquelveradaluz_@fclcapital.com', 0, '1977-02-05', 'xN7xC9J1Vto', NULL),
('4152397485', 'Breno Ian Sérgio da Mota', 'brenoiansergiodamota@dmadvogados.com', 0, '2001-02-14', 'Aah2NsiM', NULL),
('4214128512', 'Patrícia Marlene Nair Araújo', 'patriciamarlenenairaraujo-73@edpbr.com.br', 0, '2000-05-08', 'HRWcJe', NULL),
('9756785678', 'Pietra Jéssica Rosa Dias', 'pietrajessicarosadias-90@barratravel.com.br', 0, '1958-12-30', 'UganHZ8fB', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `endereco`
--
ALTER TABLE `endereco`
  ADD PRIMARY KEY (`cep`);

--
-- Indexes for table `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`codnoticia`),
  ADD KEY `cpf_noticia` (`cpf_noticia`);

--
-- Indexes for table `not_end`
--
ALTER TABLE `not_end`
  ADD KEY `codnoticia` (`codnoticia`),
  ADD KEY `cep_noticia` (`cep_noticia`);

--
-- Indexes for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD PRIMARY KEY (`codocorrencia`),
  ADD KEY `cpf_ocorrencia` (`cpf_ocorrencia`);

--
-- Indexes for table `oc_end`
--
ALTER TABLE `oc_end`
  ADD KEY `codocorrencia` (`codocorrencia`),
  ADD KEY `cep_ocorrencia` (`cep_ocorrencia`);

--
-- Indexes for table `tipuser`
--
ALTER TABLE `tipuser`
  ADD PRIMARY KEY (`idtipuser`);

--
-- Indexes for table `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD KEY `cpf` (`cpf`),
  ADD KEY `idtipuser` (`idtipuser`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`),
  ADD KEY `cep_usuario` (`cep_usuario`);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`cpf_noticia`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `not_end`
--
ALTER TABLE `not_end`
  ADD CONSTRAINT `not_end_ibfk_1` FOREIGN KEY (`codnoticia`) REFERENCES `noticia` (`codnoticia`),
  ADD CONSTRAINT `not_end_ibfk_2` FOREIGN KEY (`cep_noticia`) REFERENCES `endereco` (`cep`);

--
-- Limitadores para a tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD CONSTRAINT `ocorrencia_ibfk_1` FOREIGN KEY (`cpf_ocorrencia`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `oc_end`
--
ALTER TABLE `oc_end`
  ADD CONSTRAINT `oc_end_ibfk_1` FOREIGN KEY (`codocorrencia`) REFERENCES `ocorrencia` (`codocorrencia`),
  ADD CONSTRAINT `oc_end_ibfk_2` FOREIGN KEY (`cep_ocorrencia`) REFERENCES `endereco` (`cep`);

--
-- Limitadores para a tabela `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD CONSTRAINT `user_tipuser_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`),
  ADD CONSTRAINT `user_tipuser_ibfk_2` FOREIGN KEY (`idtipuser`) REFERENCES `tipuser` (`idtipuser`);

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`cep_usuario`) REFERENCES `endereco` (`cep`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
