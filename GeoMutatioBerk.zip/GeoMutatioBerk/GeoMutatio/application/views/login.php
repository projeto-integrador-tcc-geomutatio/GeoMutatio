<?php
print_r($this->session->userdata);
?>
<form method="POST" action="<?php echo base_url();?>index.php/Usuario/login">
												
												<input type="text" class="login-form" placeholder="E-mail" name="email">
												<br/>
												
												<input type="password" class="login-form" placeholder="Senha" name="senha">
												<br/>
												
												<input type="submit" class="login-submit" name="enviar">
												<br />

												<a href="<?php echo site_url('Redirect/cadastro')?>" class="cadastrar-modal">Ainda não possui uma conta? Cadastre-se</a>

												

											</form>