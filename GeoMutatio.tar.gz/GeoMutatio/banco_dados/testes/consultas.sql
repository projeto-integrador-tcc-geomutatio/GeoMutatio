                CADASTRAR USUARIO

insert into usuario (cpf, nome, email, datanasc, senha) values ('1958742358','Tânia Tatiane Alessandra Ramos', 'taniatatiane@startingfitness.com.br','1948-12-08', 'QZpHV5c1wZN');

                REALIZAR LOGIN
select cpf from usuario where email = 'taniatatiane@startingfitness.com.br' and senha = 'QZpHV5c1wZN';

                MOSTRAR DADOS DO USUARIO

select nome,email,senha from usuario where cpf = '2341241241';

                UPDATAR PERFIL

update usuario set senha = 'tania123' where cpf = '1958742358';

                



