-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 08-Jul-2019 às 02:57
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geomutatio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairro`
--

CREATE TABLE `bairro` (
  `nombairro` varchar(80) DEFAULT NULL,
  `idbairro` int(11) NOT NULL,
  `idcidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `nomcidade` varchar(80) DEFAULT NULL,
  `idcidade` int(11) NOT NULL,
  `iduf` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `familia`
--

CREATE TABLE `familia` (
  `nome_fam` varchar(30) DEFAULT NULL,
  `qtd_pessoas` int(3) DEFAULT '1',
  `id_familia` int(10) NOT NULL,
  `pessoas_fam` varchar(255) DEFAULT NULL,
  `recursos_nec` varchar(255) NOT NULL,
  `foto_familia` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `familia`
--

INSERT INTO `familia` (`nome_fam`, `qtd_pessoas`, `id_familia`, `pessoas_fam`, `recursos_nec`, `foto_familia`) VALUES
('Silva', 1, 2, 'Zé', 'Almofada', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logradouro`
--

CREATE TABLE `logradouro` (
  `nomlogradouro` varchar(80) DEFAULT NULL,
  `cep` varchar(11) DEFAULT NULL,
  `idlogradouro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_bairro`
--

CREATE TABLE `log_bairro` (
  `idbairro` int(11) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticia`
--

CREATE TABLE `noticia` (
  `data_noticia` date DEFAULT NULL,
  `hora_noticia` varchar(5) DEFAULT NULL,
  `desc_noticia` varchar(1350) DEFAULT NULL,
  `titulo_noticia` varchar(50) DEFAULT NULL,
  `codnoticia` varchar(5) NOT NULL,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `not_log`
--

CREATE TABLE `not_log` (
  `codnoticia` varchar(5) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencia`
--

CREATE TABLE `ocorrencia` (
  `codocorrencia` varchar(5) NOT NULL,
  `titulo_ocorrencia` varchar(50) DEFAULT NULL,
  `hora_ocorrencia` varchar(5) DEFAULT NULL,
  `desc_ocorrencia` varchar(1350) DEFAULT NULL,
  `logradouro_ocorrencia` varchar(50) DEFAULT NULL,
  `data_ocorrencia` date DEFAULT NULL,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `oc_log`
--

CREATE TABLE `oc_log` (
  `codocorrencia` varchar(5) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipuser`
--

CREATE TABLE `tipuser` (
  `desctipuser` varchar(80) DEFAULT NULL,
  `idtipuser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipuser`
--

INSERT INTO `tipuser` (`desctipuser`, `idtipuser`) VALUES
('Usuário Comum', 0),
('Administrador', 1),
('Autor', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `uf`
--

CREATE TABLE `uf` (
  `iduf` int(11) NOT NULL,
  `nomuf` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_tipuser`
--

CREATE TABLE `user_tipuser` (
  `cpf` varchar(14) DEFAULT NULL,
  `idtipuser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `cpf` varchar(14) NOT NULL,
  `tipuser` tinyint(1) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `senha` varchar(14) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nome`, `email`, `cpf`, `tipuser`, `datanasc`, `senha`, `idlogradouro`) VALUES
('Administrador', 'admin@gmail.com', '05158858942', 1, '2001-10-06', 'admin', NULL),
('Autor', 'autor@gmail.com', '14236987412', 2, '1988-05-02', 'autor', NULL),
('Usuario Comum', 'usuario@gmail.com', '23412412434', 0, '2001-05-26', 'usuario', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bairro`
--
ALTER TABLE `bairro`
  ADD PRIMARY KEY (`idbairro`),
  ADD KEY `idcidade` (`idcidade`);

--
-- Indexes for table `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`idcidade`),
  ADD KEY `iduf` (`iduf`);

--
-- Indexes for table `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`id_familia`);

--
-- Indexes for table `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`idlogradouro`);

--
-- Indexes for table `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD KEY `idbairro` (`idbairro`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Indexes for table `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`codnoticia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `not_log`
--
ALTER TABLE `not_log`
  ADD KEY `codnoticia` (`codnoticia`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Indexes for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD PRIMARY KEY (`codocorrencia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `oc_log`
--
ALTER TABLE `oc_log`
  ADD KEY `codocorrencia` (`codocorrencia`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Indexes for table `tipuser`
--
ALTER TABLE `tipuser`
  ADD PRIMARY KEY (`idtipuser`);

--
-- Indexes for table `uf`
--
ALTER TABLE `uf`
  ADD PRIMARY KEY (`iduf`);

--
-- Indexes for table `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD KEY `cpf` (`cpf`),
  ADD KEY `idtipuser` (`idtipuser`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `familia`
--
ALTER TABLE `familia`
  MODIFY `id_familia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `bairro`
--
ALTER TABLE `bairro`
  ADD CONSTRAINT `bairro_ibfk_1` FOREIGN KEY (`idcidade`) REFERENCES `cidade` (`idcidade`);

--
-- Limitadores para a tabela `cidade`
--
ALTER TABLE `cidade`
  ADD CONSTRAINT `cidade_ibfk_1` FOREIGN KEY (`iduf`) REFERENCES `uf` (`iduf`);

--
-- Limitadores para a tabela `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD CONSTRAINT `log_bairro_ibfk_1` FOREIGN KEY (`idbairro`) REFERENCES `bairro` (`idbairro`),
  ADD CONSTRAINT `log_bairro_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `not_log`
--
ALTER TABLE `not_log`
  ADD CONSTRAINT `not_log_ibfk_1` FOREIGN KEY (`codnoticia`) REFERENCES `noticia` (`codnoticia`),
  ADD CONSTRAINT `not_log_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD CONSTRAINT `ocorrencia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `oc_log`
--
ALTER TABLE `oc_log`
  ADD CONSTRAINT `oc_log_ibfk_1` FOREIGN KEY (`codocorrencia`) REFERENCES `ocorrencia` (`codocorrencia`),
  ADD CONSTRAINT `oc_log_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD CONSTRAINT `user_tipuser_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`),
  ADD CONSTRAINT `user_tipuser_ibfk_2` FOREIGN KEY (`idtipuser`) REFERENCES `tipuser` (`idtipuser`);

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
