
<?php include('header.php'); ?>

<form class="form-horizontal" style="margin-left: 5%; margin-top: 7%;" action="<?php echo site_url('Familia/createFamilia')?>"  method="POST">
  <fieldset>
    <div id="legend">
      <h2 style="margin-left: 14%;">Cadastro de Família<h2>
    </div>
    <div class="container" style="margin-top: 3%;">

      <!-- Nome -->
      <label class="control-label"  for="nome_fam">Nome</label>
      <div class="controls">
        <input type="text" id="nome_fam" name="nome_fam" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Quantidade de pessoas -->
      <label class="control-label" for="qtd_pessoas">Quantidade de Pessoas</label>
      <div class="controls">
        <input type="number" min="1" max="100" id="qtd_pessoas" name="qtd_pessoas" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Pessoas -->
      <label class="control-label"  for="pessoas_fam">Pessoas da Família (separe por vírgula)</label>
      <div class="controls">
        <input type="text" id="pessoas_fam" name="pessoas_fam" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Pessoas -->
      <label class="control-label"  for="recursos_nec">Recursos Necessitados (separe por vírgula)</label>
      <div class="controls">
        <input type="text" id="recursos_nec" name="recursos_nec" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Pessoas -->
      <label class="control-label"  for="foto_familia">Insira uma foto da família</label>
      <div class="controls">
        <input type="file" id="foto_familia" name="foto_familia" placeholder="" class="form-control">
      </div>
    </div>

 
    <div class="container" style="margin-top: 1%;">
      <!-- Button -->
      <div class="controls">
        <button class="btn btn-success">Cadastrar</button>
      </div>
    </div>
  </fieldset>
</form>

