	<?php include('header.php'); ?>

	<!-- Banner -->
	<div class="imagem-banner">
	  <div class="texto-banner">
	    <img class="logo" src="<?= base_url();?>/assets/imagens/icons/logo.png">
	    <p>Preserve sua cidade e ela preservará você!</p>
	  </div>
	</div>
	
	<!-- Fim do Banner -->
	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="info_part" style="width: 100%; height: 500px;">
			<img id="info_logo" src="<?= base_url();?>/assets/imagens/icons/jacare.png">

			<p class="info_text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

	</div>



	

	
