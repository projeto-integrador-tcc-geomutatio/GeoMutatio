<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();
?>assets/css/bootstrap.min.css">
</head>
<body>
<div style="margin-top: 7%;">

<div class="dados_usuario">
	
<?php
$usuario = $this->session->userdata('usuario');
extract($usuario);
?>
<h2 style ="margin-left: 5%;">Minha Conta: </h2>
<br>	
<div style="margin-left: 7%;">
<p>Nome: <?php echo $nome; ?></p>
<p>E-mail: <?php echo $email; ?></p>
<p>CPF: <?php echo $cpf; ?></p>
<p>Tipo de Usuário: <?php echo $tipuser; ?></p>
<p>Senha: <?php echo $senha; ?></p>
<a href="<?php echo base_url();?>index.php/Usuario/logout" class="btn btn-danger">Logout</a>
</div>

</div>
</div>
</div>
</body>
</html>