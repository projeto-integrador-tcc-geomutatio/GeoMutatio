<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Familia_model extends CI_Model{

//Funções de consulta

	function getFamilias()
	{
		$query = $this->db->query('SELECT * FROM familia');
		return $query->result();
	}

	function getFamilia($id_familia)
	{
		$query = $this->db->query('SELECT * FROM familia WHERE `id_familia` ='.$id_familia);
		return $query->row();
	}

//Funções do CRUD

	function criarFamilia()
	{
		$familia = array(
			'nome_fam' => $this->input->post('nome_fam'),
			'qtd_pessoas' => $this->input->post('qtd_pessoas'),
			'pessoas_fam' => $this->input->post('pessoas_fam'),
			'recursos_nec' => $this->input->post('recursos_nec'),
			'foto_familia' => $this->input->post('foto_familia'),
		);
		$this->db->insert('familia', $familia);
	}

	function atualizarFamilia($id_familia)
	{
		$familia = array(
			'nome_fam' => $this->input->post('nome_fam'),
			'qtd_pessoas' => $this->input->post('qtd_pessoas'),
			'pessoas_fam' => $this->input->post('pessoas_fam'),
			'foto_familia' => $this->input->post('foto_familia'),
		);
		$this->db->where('id_familia', $id_familia);
		$this->db->update('familia', $familia);
	}

	function deletarFamilia($id_familia)
	{
		$this->db->where('id_familia', $id_familia);
		$this->db->delete('familia');
	}


}
