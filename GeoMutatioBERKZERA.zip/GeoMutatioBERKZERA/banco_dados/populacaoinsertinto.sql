insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('051.588.589-42','Gustavo Baierski', 'gustavobaierski@gmail.com','2001-10-06', 'teste',1);
insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('142.369.874-12','Ruan Cunha', 'dugoso@gmail.com','1988-05-02', 'admin',1);
insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('234.124.124-34','Jonas Pinho Carolino', 'jonaspcarol@hotmail.com','2001-05-26', '12345',0);
