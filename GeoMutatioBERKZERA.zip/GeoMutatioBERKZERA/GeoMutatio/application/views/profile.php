<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Minha Conta</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();
?>assets/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<h1 class="page-header text-center">Minha Conta</h1>

<div class="dados_usuario" style="margin: 5% auto;">
<?php
$usuario = $this->session->userdata('usuario');
extract($usuario);
?>
<h2>Minha Conta: </h2>
<br>
<p>Nome: <?php echo $nome; ?></p>
<p>E-mail: <?php echo $email; ?></p>
<p>CPF: <?php echo $cpf; ?></p>
<p>Tipo de Usuário: <?php echo $tipuser; ?></p>
<p>Senha: <?php echo $senha; ?></p>
<a href="<?php echo base_url();?>index.php/Usuario/logout"

class="btn btn-danger">Logout</a>

</div>
</div>
</div>
</body>
</html>