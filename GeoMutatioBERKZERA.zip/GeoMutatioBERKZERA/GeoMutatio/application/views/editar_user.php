<?php include('header.php'); ?>

<form class="form-horizontal" style="margin-left: 5%; margin-top: 5%;" action="<?php echo site_url('Usuario/updateUsuario')?>/<?php echo $row->cpf;?>"  method="POST">
  <fieldset>
    <div id="legend">
      <legend class="">Editar Usuário</legend>
    </div>
    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="nome">Nome</label>
      <div class="controls">
        <input type="text" id="nome" name="nome" value="<?php echo $row->nome; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>
 
    <div class="control-group">
      <!-- E-mail -->
      <label class="control-label" for="email">E-mail</label>
      <div class="controls">
        <input type="text" id="email" name="email" value="<?php echo $row->email; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>

    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="cpf">CPF</label>
      <div class="controls">
        <input type="text" id="cpf" name="cpf" value="<?php echo $row->cpf; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>
 
    <div class="control-group">
      <!-- Password-->
      <label class="control-label" for="senha">Senha</label>
      <div class="controls">
        <input type="password" id="senha" name="senha" value="<?php echo $row->senha; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>

    <div class="control-group">
      <!-- Password -->
      <label class="control-label"  for="datanasc">Data de Nascimento</label>
      <div class="controls">
        <input type="date" id="datanasc" name="datanasc" value="<?php echo $row->datanasc; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>

     <div class="control-group">
      <!-- Password -->
      <label class="control-label"  for="tipuser">Tipo de Usuário</label>
      <div class="controls">
        <input type="num" maxlength="1" id="tipuser" name="tipuser" value="<?php echo $row->tipuser; ?>" placeholder="" class="input-xlarge">
      </div>
    </div>
    <br>
 
    <div class="control-group">
      <!-- Button -->
      <div class="controls">
        <button class="btn btn-success">Editar</button>
      </div>
    </div>
  </fieldset>
</form>