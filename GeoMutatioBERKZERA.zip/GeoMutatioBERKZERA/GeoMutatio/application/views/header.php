	<!DOCTYPE html>
	<html lang="zxx" class="no-js">

	<head>

		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta charset="utf-8">
   
		<title>GeoMutatio</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 

			<!--CSS ============================================= -->
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/linearicons.css"/>
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/font-awesome.min.css"/>
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/owl.carousel.css"/>
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/bootstrap.css"/>
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/main.css"/>
			<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/style.css"/>

			<!-- JQUERY e JS -->
			<script src="js/vendor/jquery-2.2.4.min.js"></script>
		
			
			
	</head>
		<body>

			<!-- MENU -->
			<header class="default-header" style="position: fixed;">
				<nav class="navbar navbar-expand-lg navbar-light">
					<div class="container">
						  <a class="navbar-brand" href="<?= base_url();?>">
						  	GeoMutatio
						  </a>
						  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						    <span class="navbar-toggler-icon"></span>
						  </button>

						  <div class="collapse navbar-collapse justify-content-end align-items-center" id="navbarSupportedContent">
						    <ul class="navbar-nav">
								<li><a href="<?= base_url();?>">Home</a></li>
								<li><a href="#ocorrencias">Ocorrências</a></li>
								<li><a href="#noticias">Notícias</a></li>
								<li><a href="#familias">Famílias?</a></li>
								<li><a href="#sobre">Sobre</a></li>


	
	

<?php

if ($this->session->userdata('usuario')) {

	$usuario = $this->session->userdata('usuario');
	
?>
								<!-- Dropdown -->
							    <li class="dropdown">
							      <a class="dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
							        Perfil
							      </a>
							      <div class="dropdown-menu">
							        <a class="dropdown-item" href="<?php echo site_url('Redirect/profile')?>">Minha conta</a>


	<?php 

	//testa para ver se é o administrador
	if ($usuario['tipuser'] == 1) { 

	?>


							        <a class="dropdown-item" href="<?php echo site_url('Redirect/usuarios')?>">Usuarios</a>
							        <a class="dropdown-item" href="3.html">Notícias</a>
							        <a class="dropdown-item" href="4.html">Ocorrências</a>

	<?php

	//testa para ver se é o autor
	 }elseif ($usuario['tipuser'] == 2) { 

	 ?>
							        <a class="dropdown-item" href="3.html">Minhas notícias</a>
							        <a class="dropdown-item" href="4.html">Minhas ocorrências</a>
	<?php

	//se não for nem administrador, nem autor, define como usuario comum 
	 }else{ 

	 ?>

							        <a class="dropdown-item" href="4.html">Minhas ocorrências</a>
	<?php } ?>



							        <a class="dropdown-item" href="<?php echo base_url();?>index.php/Usuario/logout" id="logout">Logout</a>
							        	
							        </form>
							      </div>
							    </li>

<?php
}else{
?>

								<!-- Aciona/Abre o modal -->
								<button id="botao-login">Faça o Login</button>

								<!-- Modal -->
								<div id="modal-login" class="modal">

								  <!--Conteúdo do modal -->
								  <div class="modal-conteudo">

								    <div class="modal-form">
										<p class="titulo-modal">Faça o Login</p>

											<form method="POST" action="<?php echo base_url();?>index.php/Usuario/login">
												
												<input type="text" class="login-form" placeholder="E-mail" name="email">
												<br/>
												
												<input type="password" class="login-form" placeholder="senha" name="senha">
												<br/>
												
												<input type="submit" class="login-submit" name="enviar">
												<br />

												<a href="<?php echo site_url('Redirect/cadastro')?>" class="cadastrar-modal">Ainda não possui uma conta? Cadastre-se</a>

												

											</form>
											
											<span class="fechar"></span>
								    </div>


								  </div>

								</div>
<?php } ?>

								<script type="text/javascript">
									// seleciona o modal
								var modal = document.getElementById("modal-login");

								// seleciona o botão que abre o modal
								var btn = document.getElementById("botao-login");

								// seleciona o elemento <span> que fecha o modal
								var span = document.getElementsByClassName("fechar")[0];

								// quando o usuário clicar no botão, abre o modal 
								btn.onclick = function() {
								  modal.style.display = "block";
								}

								// quando o usuário clicar em <span> (x), fecha o modal
								// não utilizada por enquanto
								span.onclick = function() {
								  modal.style.display = "none";
								}

								// quando o usuário clicar em qualquer lugar fora da tela, fecha-o
								window.onclick = function(event) {
								  if (event.target == modal) {
									modal.style.display = "none";
								  }
								}

								</script>

						    </ul>
						  </div>						
					</div>
				</nav>
			</header>
			<!-- Fim do Menu -->	
			