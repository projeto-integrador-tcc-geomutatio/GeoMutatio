<?php

include('header.php');

$familia['result'] = $this->Familia_model->getFamilias();

 $usuario = $this->session->userdata('usuario');

 for ($i=0; $i < sizeof($familia['result']); $i++) { 
 	
 	$cpf_usuario_familia[] = $familia['result'][$i]->cpf;
 	
 }

?>

	<div class="clear"></div>
    <h1 id="mapa_title" style="margin-top: 5vw; margin-left: 40vw; font-size: 2.2vw;">Minhas Famílias</h1>
	<div class="clear"></div>

    <br><br>
	
	<?php 


	$contador = 0;

	for ($i=0; $i < sizeof($familia['result']); $i++) { 
	

		

		if ($usuario['cpf'] == $cpf_usuario_familia[$i]) {


			$contador = 1;
		?>

		<div class="card" style="width: 20rem; height:44em; margin-left:5vw; margin-top:3vw; float: left;">
		<?php
						
					$foto = BASEPATH."../assets/imagens/familias/".$familias['result'][$i]->nome_fam;
					if (file_exists($foto)) {
			?>

						<img src="<?= base_url();?>/assets/imagens/familias/<?=$familia['result'][$i]->nome_fam;?>" style="width:20rem; height:19em;" class="card-img-top" >

		<?php

						}else{
							
				
			?>

						<img src="<?= base_url();?>/assets/imagens//usuarios/default.jpg" style="width:20rem; height:19em;" class="card-img-top" >




							<?php
						}

						?>



		<div class="card-body" style="float:left; height: 10vw;">
			<h5 class="card-title" style="text-align:center;"><?php echo $familia['result'][$i]->nome_fam; ?></h5>
			<br>
			<p class="card-text"><b style="color:black; font-weight:600;">Necessita de: </b><?php echo $familia['result'][$i]->recursos_nec; ?></p>
		</div>
		<ul class="list-group list-group-flush">
			<li class="list-group-item"><b style="color:black; font-weight:600;">Composta por: </b><?php echo $familia['result'][$i]->pessoas_fam; ?></li>
			<li class="list-group-item"><b style="color:black; font-weight:600;">Contato: </b><?php echo $familia['result'][$i]->telefone_fam; ?></li>
			<li class="list-group-item"><b style="color:black; font-weight:600;">Endereço: </b><?php echo $familia['result'][$i]->endereco_fam; ?></li>
		</ul>	
			<table style="height: 24vw; margin-top: 3vw;">
				<th><a href="<?php echo site_url('Familia/editMinhaFamilia');?>/<?php echo $familia['result'][$i]->id_familia?>" class="btn btn-success profile_botao" style="margin-left:2vw; cursor:pointer; width:7vw; ">Editar</a>
				<!-- Aciona/Abre o modal -->
				<th><button id="excluir_botao" style="margin-left:2vw; margin-right:0vw; float:left; width:7vw;cursor:pointer; ">Excluir</button>
			</table>
				<!-- Modal de login -->
				<div id="excluir_modal" class="modal">

					<!--Conteúdo do modal login -->
					<div class="modal-conteudo">

						<div class="modal-form" style="height:10em">
							<p class="titulo-modal">Deseja mesmo excluir esta família?</p>

							<a href="<?php echo site_url('Familia/deleteMinhaFamilia');?>/<?= $familia['result'][$i]->id_familia ?>" class="btn btnexcluir_conta">Excluir família</a>

							<a href="<?php echo site_url('Redirect/minhasfamilias')?>" class="btn btncancelar">Cancelar</a>	
									
							<span class="fechar"></span>
						</div>

					</div>
				
				</div>

					<script type="text/javascript">
									// seleciona o modal
								var modal = document.getElementById("excluir_modal");

								// seleciona o botão que abre o modal
								var btn = document.getElementById("excluir_botao");

								// seleciona o elemento <span> que fecha o modal
								var span = document.getElementsByClassName("fechar")[0];

								// quando o usuário clicar no botão, abre o modal 
								btn.onclick = function() {
								  modal.style.display = "block";
								}

								// quando o usuário clicar em <span> (x), fecha o modal
								// não utilizada por enquanto
								span.onclick = function() {
								  modal.style.display = "none";
								}

								// quando o usuário clicar em qualquer lugar fora da tela, fecha-o
								window.onclick = function(event) {
								  if (event.target == modal) {
									modal.style.display = "none";
								  }
								}

								</script>						
		</ul>
	</div>					
				
			</div>
						
	<?php }}

		if (@$contador == 0) {
			echo "<p style='margin-left:40.5vw;'>Você não possui nenhuma família cadastrada!</p>";
		}
		?>