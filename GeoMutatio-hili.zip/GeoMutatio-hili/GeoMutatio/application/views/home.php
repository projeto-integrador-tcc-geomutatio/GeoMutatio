	<?php include('header.php'); ?>

	<!-- Banner -->
	<div class="imagem-banner">
	  <div class="texto-banner">
	    <img class="logo" src="<?= base_url();?>/assets/imagens/icons/logo.png">
	    <p>Preserve sua cidade e ela preservará você!</p>
	  </div>
	</div>
	
	<!-- Fim do Banner -->
	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="info_part" style="width: 100%; height: 40vw;">
			<img id="info_logo" src="<?= base_url();?>/assets/imagens/icons/jacare.png">

			<h2 class="info_titulo"> A cidade inteira em suas mãos</p>
		<p class="info_text"> Cadastre e visualize diversas ocorrências e notícias acerca das mudanças climáticas e geológicas de Joinville. Receba as principais noticias sobre os principais eventos beneficentes de sua região.</p>

	</div>
	</div>



	<div class="clear"></div>

	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="home_noticias">

		<div class="cards_noticias">

			<a href="#" class="card_noticia_link">

				<div class="card_noticia" id="first_card_noticia" >

					<img src="<?= base_url();?>/assets/imagens/noticias/alagamento_centro.jpg" class="background_card_noticia">

					<h4 class="home_noticia_txt">Alagamento no centro prejudica a circulação dos ônibus</h4>

					<p class="home_noticia_link">Confira a notícia completa</p>

				</div>
			</a>

			<a href="#" class="card_noticia_link">
				<div class="card_noticia">

					<img src="<?= base_url();?>/assets/imagens/noticias/deslizamento_terra.jpg" class="background_card_noticia">					

					<h4 class="home_noticia_txt">Deslizamento de terra prejudica moradores do Iririú</h4>

					<p class="home_noticia_link">Confira a notícia completa</p>

				</div>
			</a>

			<a href="#" class="card_noticia_link">
				<div class="card_noticia">

					<img src="<?= base_url();?>/assets/imagens/noticias/buraco_rua.jpg" class="background_card_noticia">

					<h4 class="home_noticia_txt">Buracos preenchem as ruas do bairro Morro do Meio</h4>

					<p class="home_noticia_link">Confira a notícia completa</p>

				</div>
			</a>
		</div>

	</div>

	<div class="clear"></div>

	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="info_part" style="width: 100%; height: 300px;">
	</div>

	

	
