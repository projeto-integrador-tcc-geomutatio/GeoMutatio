<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Crud_model');
	}

	public function index()
	{
		$this->load->view('home');
	}

	public function cadastro()
	{
		$data['result'] = $this->Crud_model->getAllData(); 
		$this->load->view('cadastro_user', $data);
	}

	public function create()
	{
		$this->Crud_model->createData();
		redirect("Welcome/cadastro");
	}

	public function edit($cpf)
	{
		$data['row'] = $this->Crud_model->getData($cpf);
		$this->load->view('editar_user', $data);
		
	}

	public function update($cpf)
	{
		$this->Crud_model->updateData($cpf);
		redirect("Welcome/cadastro");
	}

	public function delete($cpf)
	{
		$this->Crud_model->deteleData($cpf);
		redirect("Welcome/cadastro");
	}

	function search_keyword()
   {
       $dado=$this->input->post('submit');
       $dado['usuario']=$this->Crud_model->pesquisa($dado);

       $this->load->view('cadastro_user', $dado);

   }
}
