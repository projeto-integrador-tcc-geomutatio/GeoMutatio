<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
		parent::__construct();
	}

	function createData()
	{
		$data = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $this->input->post('cpf'),
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
		);
		$this->db->insert('usuario', $data);
	}	

	function getAllData()
	{
		$query = $this->db->query('SELECT * FROM usuario');
		return $query->result();
	}

	function getData($cpf)
	{
		$query = $this->db->query('SELECT * FROM usuario WHERE `cpf` ='.$cpf);
		return $query->row();
	}

	function updateData($cpf)
	{
		$data = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $this->input->post('cpf'),
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
		);
		$this->db->where('cpf', $cpf);
		$this->db->update('usuario', $data);
	}

	function deteleData($cpf)
	{
		$this->db->where('cpf', $cpf);
		$this->db->delete('usuario');
	}

	function pesquisa($nome)
   {
       $this->db->like('nome',$nome);
       $query  =   $this->db->get('usuario');
       return $query->result_array();
       
   }


}	