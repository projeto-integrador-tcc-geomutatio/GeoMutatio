<?php

include('Redirect.php');
defined('BASEPATH') OR exit('No direct script access allowed');

Class Noticia extends Redirect{


//Funções do CRUD


	public function createNoticia(){
		$this->Noticia_model->criarNoticia();
		redirect("Redirect/noticias");
	}
	public function editNoticia($codnoticia)
	{
		$noticia['row'] = $this->Noticia_model->getNoticia($codnoticia);
		$this->load->view('editar_noticia', $noticia);
		
	}

	public function updateNoticia($codnoticia)
	{
		$this->Noticia_model->atualizarNoticia($codnoticia);
		redirect("Redirect/tabela_noticias");
	}

	public function deleteNoticia($codnoticia)
	{
		$this->Noticia_model->deletarNoticia($codnoticia);
		redirect("Redirect/tabela_noticias");
	}


}