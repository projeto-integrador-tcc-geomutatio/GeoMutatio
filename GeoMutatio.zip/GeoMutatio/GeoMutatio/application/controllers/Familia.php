<?php

include('Redirect.php');
defined('BASEPATH') OR exit('No direct script access allowed');

Class Familia extends Redirect{


//Funções do CRUD


	public function createFamilia(){
		$this->Familia_model->criarFamilia();
		redirect("Redirect/tabela_familias");
	}
	public function editFamilia($id_familia)
	{
		$familia['row'] = $this->Familia_model->getFamilia($id_familia);
		$this->load->view('editar_familia', $familia);
		
	}

	public function updateFamilia($id_familia)
	{
		$this->Familia_model->atualizarFamilia($id_familia);
		redirect("Redirect/tabela_familias");
	}

	public function deleteFamilia($id_familia)
	{
		$this->Familia_model->deletarFamilia($id_familia);
		redirect("Redirect/tabela_familias");
	}


}