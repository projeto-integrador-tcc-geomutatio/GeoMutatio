<?php

include('Redirect.php');
defined('BASEPATH') OR exit('No direct script access allowed');

Class Ocorrencia extends Redirect{


	public function createOcorrencia(){

		$this->Ocorrencia_model->criarOcorrencia();
		redirect("Redirect/home");
	}

	public function editOcorrencia($id_ocorrencia){

		$ocorrencia['row'] = $this->Ocorrencia_model->getOcorrencias($id_ocorrencia);
		$this->load->view('editar_ocorrencia', $ocorrencia);
		
	}

	public function updateOcorrencia($id_ocorrencia){

		$this->Ocorrencia_model->atualizarOcorrencia($id_ocorrencia);
		redirect("Redirect/ocorrencias");
	}

	public function deleteOcorrencia($id_ocorrencia){

		$this->Ocorrencia_model->deletarOcorrencia($id_ocorrencia);
		redirect("Redirect/ocorrencias");
	}	



}
