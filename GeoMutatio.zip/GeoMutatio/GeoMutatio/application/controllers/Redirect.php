<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Redirect extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->helper('url');
		$this->load->model('Usuario_model');
		$this->load->model('Familia_model');
		$this->load->model('Noticia_model');
		$this->load->model('Ocorrencia_model');
	}

	public function index(){

		//comando que limpa a session caso haja algum problema :
		//$this->session->unset_userdata('usuario');


		//carrega a session
		$this->load->library('session');

		//restrict users to go back to login if session has been set
		if($this->session->userdata('usuario')){
			$this->load->view('home');
		}else{
			$this->load->view('home');
			
		}
	}

	public function home(){

		//load session library
		$this->load->library('session');
	
		//restrict users to go to home if not logged in
		if($this->session->userdata('usuario')){
			$this->load->view('profile');
		}else{
			redirect('/');
		}
	}
	
	public function cadastro(){

		$usuario['result'] = $this->Usuario_model->getUsuarios(); 
		$this->load->view('cadastro_user', $usuario);
	}

	public function profile(){
		$this->load->view('profile');
	}

	public function usuarios(){
		$this->load->view('usuarios');
	}

	public function cad_familia(){
		$familia['result'] = $this->Familia_model->getFamilias(); 
		$this->load->view('cadastro_familia', $familia);
	}		
	
	public function tabela_familias(){
		$this->load->view('tabela_familias');
	}

	public function familias(){
		$this->load->view('familias');
	}

	public function cad_noticia(){	
		$noticia['result'] = $this->Noticia_model->getNoticias(); 
		$this->load->view('cadastro_noticia', $noticia);
	}

	public function tabela_noticias(){
		$this->load->view('tabela_noticias');
	}

	public function noticias(){
		$this->load->view('noticias');
	}

	public function ocorrencias(){
		$this->load->view('ocorrencias');
	}

	public function sobre(){
		$this->load->view('sobre');
	}	

}
