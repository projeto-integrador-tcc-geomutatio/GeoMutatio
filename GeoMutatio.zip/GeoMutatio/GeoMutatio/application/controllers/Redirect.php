<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Redirect extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->helper('url');
		$this->load->model('Usuario_model');
	}

	public function index(){

		//comando que limpa a session caso haja algum problema :
		//$this->session->unset_userdata('usuario');


		//carrega a session
		$this->load->library('session');

		//restrict users to go back to login if session has been set
		if($this->session->userdata('usuario')){
			$this->load->view('home');
		}else{
			$this->load->view('home');
			
		}
	}

	public function home(){

		//load session library
		$this->load->library('session');
	
		//restrict users to go to home if not logged in
		if($this->session->userdata('usuario')){
			$this->load->view('profile');
		}else{
			redirect('/');
		}
	}
	
	public function cadastro(){

		$usuario['result'] = $this->Usuario_model->getUsuarios(); 
		$this->load->view('cadastro_user', $usuario);
	}

	public function profile(){
		$this->load->view('profile');
	}
	
	public function usuarios(){
		$this->load->view('usuarios');
	}

	public function cad_noticia(){
		$this->load->view('cadastro_noticia');
	}

}
