<?php
include('header.php');
?>
    <div class="clear"></div>
   <!-- Make sure you put this AFTER Leaflet's CSS -->
        <h1 id="mapa_title" style="margin-top: 5%; margin-left: 38%;">Mapa de Ocorrências</h1>

    <div class="clear"></div>
        
    </head>
    <body>

    <div id="mapid" style="height: 510px;" onmouseover="getLocation()" ></div>

    <script>
        // Declara a variável que recebe o mapa e define a latitude e longitude iniciais
        var mymap = L.map('mapid').setView([-26.3017, -48.84457], 13);

        //Linka o layout do mapa com o mapbox através de um código de acesso
        L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
	attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	maxZoom: 18,
	id: 'mapbox.streets',
	accessToken: 'pk.eyJ1IjoiZ2VvbXV0YXRpbyIsImEiOiJjazEwcTl2bnEwMTY0M2xub2Ywc3poNXZyIn0.XWV7EofCREuGA9f9aiXVew'
}).addTo(mymap);


    //marcador de exemplo
/*    var marker = L.marker([-26.3017, -48.84210]).addTo(mymap);
    marker.bindPopup("<b>Terremoto</b><br>Rua Blumenau").openPopup();


    var marker = L.marker([-26.3067, -48.84230]).addTo(mymap);
    marker.bindPopup("<b>Alagamento</b><br>sallalsa").openPopup();
*/

    var popup = L.popup();


    //Função que mostra a latitude e longitude de onde foi clicado no mapa
    function onMapClick(e) {

        var latlng = e.latlng.toString();

    	popup
    		.setLatLng(e.latlng)
    		.setContent(//'Você clicou nas coordenadas: ' + e.latlng.toString() + 
            '<br><form method="POST" action="<?php echo site_url("Ocorrencia/createOcorrencia")?>"> <input type="hidden" id="local_ocorrencia" name="local" value=""> <input type="hidden" id="cpf" name="cpf" value=""> <input type="hidden" id="data_ocorrencia" name="data_ocorrencia" value=""> <select name="tipo_ocorrencia"> <option value="buraco">Buraco</option> <option value="alagamento">Alagamento</option> <option value="deslizamento">Deslizamento de Terra</option> </select><br> <input type="submit" value="Cadastrar ocorrência" /></form>')
    		.openOn(mymap);

            var latlng = e.latlng.toString();
            document.getElementById("local_ocorrencia").value = latlng;

<?php

    date_default_timezone_set('America/Sao_Paulo');
    $date = date('Y-m-d');





    // function converteData($date){

    //     $dateExplode = explode('-',$date);

    //     $dateReverse = array_reverse($dateExplode);

    //     $dateFinal = implode('-',$dateReverse);

    //     return $dateFinal;

    // }





    $usuario = $this->session->userdata('usuario');
    
    $cpf = $usuario['cpf'];

?>

    var data_ocorrencia = "<?php echo $date;?>"
    document.getElementById("data_ocorrencia").value = data_ocorrencia;


    var cpf = "<?php echo $cpf;?>"
    document.getElementById("cpf").value = cpf;

    }
<?php
    
    //Valida se existe algum usuário logado
    if ($this->session->userdata('usuario')) {

?>  


mymap.on('click', onMapClick);



<?php
        }  
?>


    </script>


    <?php


    //Início do filtro
     
    $ocorrenciasArray = $this->Ocorrencia_model->getOcorrencias();
    // $count = count($ocorrenciasArray);

    //FILTRO AQUI
    $filtro = 'tudo';
   
    $filtro_usuario = $this->input->post('filtro_ocorrencia');

    if ($filtro_usuario == 'buraco') {
        $filtro = 'buraco';
    }elseif($filtro_usuario == 'alagamento'){
        $filtro = 'alagamento';
    }elseif($filtro_usuario == 'deslizamento'){
        $filtro = 'deslizamento';
    }else{
        $filtro = 'tudo';
    }

        foreach ($ocorrenciasArray as $ocorrencia) {

        $tipo_ocorrencia = $ocorrencia->tipo_ocorrencia;

        if ($filtro == $tipo_ocorrencia) {
            
        


             $local = explode(',', $ocorrencia->local); 
             $nome_ocorrencia = $ocorrencia->nome_ocorrencia;
             $tipo_ocorrencia = $ocorrencia->tipo_ocorrencia;
             $data_ocorrencia = $ocorrencia->data_ocorrencia;
             $imagem_ocorrencia = $ocorrencia->imagem_ocorrencia;

            ?>

            <script type="text/javascript">
                var local1 = "<?php echo $local[0];?>"
                var local2 = "<?php echo $local[1];?>"
                var tipo_ocorrencia = "<?php echo $tipo_ocorrencia;?>"
                var data_ocorrencia = "<?php echo $data_ocorrencia;?>"
                var imagem_ocorrencia = "<?php echo $imagem_ocorrencia;?>"
                var nome_ocorrencia = "<?php echo $nome_ocorrencia;?>"



                var icone = L.icon({
                    iconUrl: '<?= base_url();?>/assets/imagens/ocorrencias/'+ imagem_ocorrencia,

                    iconSize:     [38, 95], // size of the icon
                    iconAnchor:   [20, 94], // point of the icon which will correspond to marker's location
                    popupAnchor:  [0, -30] // point from which the popup should open relative to the iconAnchor
                });

                var marker = L.marker([local1, local2],{icon: icone}).addTo(mymap); marker.bindPopup("<b><?php echo $nome_ocorrencia;?></b><br>" + "<b style='color: black; font-size:10px;'><?php echo $data_ocorrencia;?></b>").openPopup();
            </script>
<?php
            }

            if ($filtro == 'tudo') {
                

             $local = explode(',', $ocorrencia->local); 
             $nome_ocorrencia = $ocorrencia->nome_ocorrencia;
             $tipo_ocorrencia = $ocorrencia->tipo_ocorrencia;
             $data_ocorrencia = $ocorrencia->data_ocorrencia;
             $imagem_ocorrencia = $ocorrencia->imagem_ocorrencia;

            ?>

            <script type="text/javascript">
                var local1 = "<?php echo $local[0];?>"
                var local2 = "<?php echo $local[1];?>"
                var tipo_ocorrencia = "<?php echo $tipo_ocorrencia;?>"
                var data_ocorrencia = "<?php echo $data_ocorrencia;?>"
                var imagem_ocorrencia = "<?php echo $imagem_ocorrencia;?>"
                var nome_ocorrencia = "<?php echo $nome_ocorrencia;?>"



                var icone = L.icon({
                    iconUrl: '<?= base_url();?>/assets/imagens/ocorrencias/'+ imagem_ocorrencia,

                    iconSize:     [38, 95], // size of the icon
                    iconAnchor:   [20, 94], // point of the icon which will correspond to marker's location
                    popupAnchor:  [0, -30] // point from which the popup should open relative to the iconAnchor
                });

                var marker = L.marker([local1, local2],{icon: icone}).addTo(mymap); marker.bindPopup("<b style='color:#54b07b;'><?php echo $nome_ocorrencia;?></b><br>" + "<b style='color: #8e8e8e; font-size:10px;'><img style='width:25%'  src='<?= base_url();?>/assets/imagens/icons/date.png'><?php echo $data_ocorrencia;?></b>").openPopup();
            </script>

<?php     
            }
       }

      

    ?>


<p id="demo"></p>


    <script>
var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}
$i = 0;
function showPosition(position) {
  
  if ($i < 1) { 

  var marker = L.marker([position.coords.latitude, position.coords.longitude]).addTo(mymap); marker.bindPopup("Sua localização").openPopup();

    $i++;
    }

}

</script>

<h5> Filtrar por: </h5>
<form method="post">
    <select name="filtro_ocorrencia">
        <option value="tudo">Tudo</option> 
        <option value="buraco">Buraco</option> 
        <option value="alagamento">Alagamento</option>
        <option value="deslizamento">Deslizamento de terras</option>
    </select>
    <input type="submit" value="Filtrar">
</form>


    
        
    </body>
</html>