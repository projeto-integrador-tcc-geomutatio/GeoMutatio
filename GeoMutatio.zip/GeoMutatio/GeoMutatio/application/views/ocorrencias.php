<?php
include('header.php');
?>
    <div class="clear"></div>
   <!-- Make sure you put this AFTER Leaflet's CSS -->
        <h1 id="mapa_title" style="margin-top: 5%; margin-left: 38%;">Mapa de Ocorrências</h1>

    <div class="clear"></div>
        
    </head>
    <body>

    <div id="mapid" style="height: 510px;"></div>

    <script>
        // Declara a variável que recebe o mapa e define a latitude e longitude iniciais
        var mymap = L.map('mapid').setView([-26.3017, -48.84457], 13);

        //Linka o layout do mapa com o mapbox através de um código de acesso
        L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
	attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	maxZoom: 18,
	id: 'mapbox.streets',
	accessToken: 'pk.eyJ1IjoiZ2VvbXV0YXRpbyIsImEiOiJjazEwcTl2bnEwMTY0M2xub2Ywc3poNXZyIn0.XWV7EofCREuGA9f9aiXVew'
}).addTo(mymap);


    //marcador de exemplo
    var marker = L.marker([-26.3017, -48.84210]).addTo(mymap);
    marker.bindPopup("<b>Terremoto</b><br>Rua Blumenau").openPopup();


    var marker = L.marker([-26.3067, -48.84230]).addTo(mymap);
    marker.bindPopup("<b>Alagamento</b><br>sallalsa").openPopup();


    var popup = L.popup();


    //Função que mostra a latitude e longitude de onde foi clicado no mapa
    function onMapClick(e) {

        var latlng = e.latlng.toString();

    	popup
    		.setLatLng(e.latlng)
    		.setContent('Você clicou nas coordenadas: ' + e.latlng.toString() + 
            '<br><form method="POST" action="<?php echo site_url("Ocorrencia/createOcorrencia")?>"> <input type="hidden" id="local_ocorrencia" name="local" value=""> <input type="hidden" name="nome_ocorrencia" value="buracasso"> <input type="hidden" name="tipo_ocorrencia" value="buraco"> <input type="submit" value="Cadastrar" /></form>')
    		.openOn(mymap);

            var latlng = e.latlng.toString();
            document.getElementById("local_ocorrencia").value = latlng;
    }

mymap.on('click', onMapClick);
    </script>


    <?php

        $ocorrenciasArray = $this->Ocorrencia_model->getOcorrencias();


        $count = count($ocorrenciasArray);



        foreach ($ocorrenciasArray as $ocorrencia) {

             $local = explode(',', $ocorrencia->local); 

            ?>

            <script type="text/javascript">
                var local1 = "<?php echo $local[0];?>"
                var local2 = "<?php echo $local[1];?>"

                var marker = L.marker([local1, local2]).addTo(mymap); marker.bindPopup("<b>Alagamento</b><br>sallalsa").openPopup();
            </script>
<?php

       }

      

    ?>
        
    </body>
</html>