<?php
include('header.php');
?>
    <div class="clear"></div>
   <!-- Make sure you put this AFTER Leaflet's CSS -->
        <h1 id="mapa_title" style="margin-top: 5%; margin-left: 38%;">Mapa de Ocorrências</h1>

    <div class="clear"></div>
        
    </head>
    <body>

    <div id="mapid" style="height: 180px;"></div>

    <script>
        var mymap = L.map('mapid').setView([-26.3017, -48.84457], 13);

        L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
	attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	maxZoom: 18,
	id: 'mapbox.streets',
	accessToken: 'pk.eyJ1IjoiZ2VvbXV0YXRpbyIsImEiOiJjazEwcTl2bnEwMTY0M2xub2Ywc3poNXZyIn0.XWV7EofCREuGA9f9aiXVew'
}).addTo(mymap);



    var marker = L.marker([-26.3017, -48.84210]).addTo(mymap);
    marker.bindPopup("<b>eae bixa</b><br>clicasse????").openPopup();



    function onMapClick(e) {
	alert("clicasse em " + e.latlng);
}   

mymap.on('click', onMapClick);
    </script>
        
    </body>
</html>