<?php include('header.php'); ?>

<form class="form-horizontal" style="margin-left: 5%; margin-top: 7%;" action="<?php echo site_url('Familia/updateFamilia')?>/<?php echo $row->id_familia;?>"  method="POST">
  <fieldset>
    <div id="legend">
       <h2 style="margin-left: 14%;">Editar Família<h2>
    </div>
    <div class="container" style="margin-top: 1%;">
      <!-- Nome -->
      <label class="control-label"  for="nome_fam">Nome</label>
      <div class="controls">
        <input type="text" id="nome_fam" name="nome_fam" value="<?php echo $row->nome_fam; ?>" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Quantidade de pessoas -->
      <label class="control-label" for="qtd_pessoas">Quantidade de Pessoas</label>
      <div class="controls">
        <input type="number" min="1" max="100" id="qtd_pessoas" name="qtd_pessoas" value="<?php echo $row->qtd_pessoas; ?>" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Pessoas -->
      <label class="control-label"  for="pessoas_fam">Pessoas da Família (separe por vírgula)</label>
      <div class="controls">
        <input type="text" id="pessoas_fam" name="pessoas_fam" value="<?php echo $row->pessoas_fam; ?>" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Quantidade de pessoas -->
      <label class="control-label" for="qtd_pessoas">Recursos Necessitados</label>
      <div class="controls">
        <input type="text" id="recursos_nec" name="recursos_nec" value="<?php echo $row->recursos_nec; ?>" placeholder="" class="form-control">
      </div>
    </div>
    <br>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Button -->
      <div class="controls">
        <button class="btn btn-success">Editar</button>
      </div>
    </div>
  </fieldset>
</form>