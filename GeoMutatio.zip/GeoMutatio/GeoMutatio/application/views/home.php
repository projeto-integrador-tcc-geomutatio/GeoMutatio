	<?php include('header.php'); 
	
	$noticias['result'] = $this->Noticia_model->getLastsNoticias();
	?>

	<!-- Banner -->
	<div class="imagem-banner">
	  <div class="texto-banner">
	    <img class="logo" src="<?= base_url();?>/assets/imagens/icons/logo.png">
	    <p>Preserve sua cidade e ela preservará você!</p>
	  </div>
	</div>
	
	<!-- Fim do Banner -->
	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="info_part" style="width: 100%; height: 42vw;">
			<img id="info_logo" src="<?= base_url();?>/assets/imagens/icons/jacare.png">

			<h2 class="info_titulo"> A cidade inteira em suas mãos</p>
			<p class="info_text"> Cadastre e visualize diversas ocorrências e notícias acerca das mudanças climáticas e geológicas de Joinville. Receba as principais noticias sobre os principais eventos beneficentes de sua região.</p>

	</div>

	<div class="clear"></div>

	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="home_noticias">

		<div class="cards_noticias">

		<?php foreach ($noticias['result'] as $data) { ?>

			<a class="card_noticia_link" href="<?php echo site_url('Redirect/noticia')?>/<?= $data->codnoticia ?>">

				<div class="card_noticia" id="first_card_noticia" >

					<?php
						
						$foto = BASEPATH."../assets/imagens/noticias/".$data->titulo_noticia;
						if (file_exists($foto)) {
							?>
 		
							<img class="background_card_noticia" src="<?= base_url();?>/assets/imagens/noticias/<?=$data->titulo_noticia;?>" alt="Card image cap" style="height: 20vw; width: 20.99vw;>
						<?php

						}else{
								
							?>

							<img class="background_card_noticia" src="<?= base_url();?>/assets/imagens/usuarios/default.jpg" alt="Card image cap">

							<?php
						}

						?>	

					<h4 class="home_noticia_txt"><?php echo $data->titulo_noticia; ?></h4>

					<p class="home_noticia_link">Confira a notícia completa</p>

				</div>
			</a>

		<?php } ?>	
			
		</div>

	</div>

	<div class="clear"></div>

	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	

	<div class="clear"></div>

	<div class="info_part" style="width: 100%; height: 300px;">
	</div>

	

	<?php include('footer.php'); 
