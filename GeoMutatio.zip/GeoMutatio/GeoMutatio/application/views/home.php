	<?php include('header.php'); ?>

	<!-- Banner -->
	<div class="imagem-banner">
	  <div class="texto-banner">
	    <img class="globoBanner" src="<?= base_url();?>/assets/imagens/globo.png">
	    <p>"Alguma frase de efeito"</p>
	  </div>
	</div>
	
	<!-- Fim do Banner -->
	<div class="borda_cate_Index">
		<section class="bordas_index cor_bord"></section>
	    <section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
		<section class="bordas_index cor_bord"></section>
		<section class="bordas_index cor_bord1"></section>
	</div>	



	

	
