	<?php include('header.php'); ?>

	<!-- Banner -->
	<div class="imagem-banner">
	  <div class="texto-banner">
	    <img class="globoBanner" src="http://localhost/GeoMutatio/GeoMutatio/assets/imagens/globo.png">
	    <p>"Alguma frase de efeito"</p>
	  </div>
	</div>
	
	<!-- Fim do Banner -->



	

	
