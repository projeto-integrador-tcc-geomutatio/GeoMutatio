
<?php include('header.php'); ?>

<form class="form-horizontal" style="margin-left: 5%; margin-top: 7%;" action="<?php echo site_url('Noticia/createNoticia')?>"  method="POST">
  <fieldset>
    <div id="legend">
      <h2 style="margin-left: 14%;">Cadastro de Notícias<h2>
    </div>
    <div class="container" style="margin-top: 3%;">

      <input type="hidden" name="tipuser" value="0">
      <!-- Titulo da Notícia -->
      <label class="control-label"  for="titulo_noticia">Titulo da Notícia</label>
      <div class="controls">
        <input type="text" id="titulo_noticia" name="titulo_noticia" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Descrição da Notícia -->
      <label class="control-label" for="desc_noticia">Descrição da Notícia</label>
      <div class="controls">
        <textarea id="desc_noticia" name="desc_noticia" placeholder="" class="form-control" rows=7></textarea>
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Data da Notícia -->
      <label class="control-label"  for="data_noticia">Data da Notícia</label>
      <div class="controls">
        <input type="date" id="data_noticia" name="data_noticia" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Imagens da Notícia-->
      <label class="control-label" for="foto_noticia">Imagens da Notícias</label>
      <div class="controls">
        <input type="file" id="foto_noticia" name="foto_noticia" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Button -->
      <div class="controls">
        <button class="btn btn-success">Cadastrar</button>
      </div>
    </div>
  </fieldset>
</form>

