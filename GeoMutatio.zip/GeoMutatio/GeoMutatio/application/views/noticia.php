<?php

    include('header.php');

    $usuarios['result'] = $this->Usuario_model->getUsuarios();

    foreach($usuarios['result'] as $usuario){

        if($usuario->cpf == $row->cpf){

            $autor_noticia = $usuario->nome;
            
        }else{

        }
    }

    
    
?>

<div class="clear"></div>

<div class="parede"></div>
<div class="parede2"></div>

<h1 class="titulo_noticia2"> <?php echo $row->titulo_noticia; ?> </h1> 

<h1 class="subtitulo_noticia"> <?php echo $row->subtitulo_noticia; ?> </h1> 

<div class="data_from">    

    <p class="autor_noticia"> Por <?php echo $autor_noticia; ?> </p> 

    <p class="data_noticia"> <?php echo $row->data_noticia; ?></p> 
    
</div>

<hr style="width: 48%; margin-left:26%; margin-top: 3%;">  

<img style="width:46%;height:auto;margin-left:1%;" src="<?= base_url();?>/assets/imagens/noticias/buraco_rua.jpg" alt="Card image cap">

<div class="parede3"></div>
<div class="parede4"></div>

<h1 class="desc_noticia"> <?php echo nl2br($row->desc_noticia); ?> </h1>
