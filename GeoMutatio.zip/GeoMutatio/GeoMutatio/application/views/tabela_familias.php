<?php

include('header.php');

if ($this->session->userdata('usuario')) {

  $usuario = $this->session->userdata('usuario');

  if ($usuario['tipuser'] == 1 OR 2) { 

    $familia['result'] = $this->Familia_model->getFamilias();
  
?>

<h1 style="margin-top: 7vw; text-align: center"> Tabela de Famílias Cadastradas</h1>

<table class="table table-borderless" style="width: 70vw; margin-left: 15vw; margin-top: 5vw;">
  <thead>
    <tr>
      <th scope="col">ID família</th>
      <th scope="col">Nome</th>
      <th scope="col">Pessoas da Família</th>
      <th scope="col">Recursos Necessitados</th>
      <th scope="col">Telefone</th>
      <th scope="col">Endereço</th>
      <th scope="col">Cadastrada por</th>
    </tr>
  </thead>
  <tbody>

  	<?php foreach ($familia['result'] as $row) { ?>

    	<tr>
    	    <th scope="row"><?php echo $row->id_familia; ?></th>
    	    <td><?php echo $row->nome_fam; ?></td>
          <td><?php echo $row->pessoas_fam; ?></td>
          <td><?php echo $row->recursos_nec; ?></td>
          <td><?php echo $row->telefone_fam; ?></td>
          <td><?php echo $row->endereco_fam; ?></td>
          <td><?php echo $row->cpf; ?> </td>

    	    <td> <a href="<?php echo site_url('Familia/editFamilia');?>/<?php echo $row->id_familia;?>">Editar</a></td>
          <td> <p id="deletar_botao" style="cursor:pointer; color:#007bff;" >Deletar</p></td>
          <!-- Modal de login -->
          <div id="excluir_modal" class="modal">

              <!--Conteúdo do modal login -->
              <div class="modal-conteudo">

                <div class="modal-form" style="height:10em">
                  <p class="titulo-modal">Deseja mesmo excluir esta família?</p>

                  <a href="<?php echo site_url('Familia/deleteFamilia');?>/<?php echo $row->id_familia;?>" class="btn btnexcluir_conta">Excluir família</a>

                  <a href="<?php echo site_url('Redirect/tabela_familias')?>" class="btn btncancelar">Cancelar</a>	
                      
                  <span class="fechar"></span>
                </div>

              </div>

              </div>

              <script type="text/javascript">
                      // seleciona o modal
                    var modal = document.getElementById("excluir_modal");

                    // seleciona o botão que abre o modal
                    var btn = document.getElementById("deletar_botao");

                    // seleciona o elemento <span> que fecha o modal
                    var span = document.getElementsByClassName("fechar")[0];

                    // quando o usuário clicar no botão, abre o modal 
                    btn.onclick = function() {
                      modal.style.display = "block";
                    }

                    // quando o usuário clicar em <span> (x), fecha o modal
                    // não utilizada por enquanto
                    span.onclick = function() {
                      modal.style.display = "none";
                    }

                    // quando o usuário clicar em qualquer lugar fora da tela, fecha-o
                    window.onclick = function(event) {
                      if (event.target == modal) {
                      modal.style.display = "none";
                      }
                    }

                    </script>
    	</tr>

    <?php } ?>	

  </tbody>
</table>

<a  style="margin-left: 47vw; margin-top:5vw;" class="btn btn-success" href="<?php echo site_url('Redirect/cad_familia')?>">Cadastrar familia</a>


<?php
  }else{
    redirect('/');
  }
}else{
  redirect('/');
}
?>