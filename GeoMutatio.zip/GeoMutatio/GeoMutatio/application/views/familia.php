<?php

    include('header.php');  
    
?>

<div class="clear"></div>

<h1 class="titulo_familia" style="text-align:center;"> <?php echo $row->nome_fam; ?> </h1> 

<hr style="width: 50%; text-align:center;margin-right:auto;margin-left:auto;">  

<img style="width:46%;height:auto;margin-left:27%;" src="<?= base_url();?>/assets/imagens/familias/familia.jpg" alt="Card image cap">

<img style="width:16%;height:auto;margin-left:27%;" src="<?= base_url();?>/assets/imagens/icons/movel.png" alt="Card image cap">

<img style="width:16%;height:auto;margin-left:27%;" src="<?= base_url();?>/assets/imagens/icons/travesseiro.png" alt="Card image cap">

