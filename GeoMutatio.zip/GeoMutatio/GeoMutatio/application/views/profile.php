<?php 

	include('header.php'); 

	$usuario = $this->session->userdata('usuario');
	extract($usuario);
?>

<!DOCTYPE html>
	<html>
		<head>
			<meta charset="utf-8">
			<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
		</head>


		<body id="profile_background">
			<div class="profile_section">

					<div class="clear"></div>

				<h2 id="profile_title">Minha Conta: </h2>

					<div class="clear"></div>


						<?php
						
						$foto = BASEPATH."../assets/imagens/usuarios/".$cpf;
						if (file_exists($foto)) {
							?>

							<img id="profile_photo" src="<?= base_url();?>/assets/imagens/usuarios/<?=$cpf?>">
						<?php

						}else{
							
						
							?>

							<img id="profile_photo" src="<?= base_url();?>/assets/imagens/usuarios/default">

							<?php
						}

						?>
						
						
				<div class="informacoes_perfil">
					
						<h5 class="info_title">Nome:</h5>
						<div class="clear"></div>
						<p class="info_profile"> <?php echo $nome; ?></p>

						<h5 class="info_title">E-mail:</h5>
						<div class="clear"></div>
						<p class="info_profile"> <?php echo $email; ?></p>
				</div>

				<div class="informacoes_perfil">

						<h5 class="info_title">CPF: </h5>
						<div class="clear"></div>
						<p class="info_profile"><?php echo ($this->Usuario_model->valida_cpf($cpf)); ?></p>

						<h5 class="info_title">Senha:</h5>
						<div class="clear"></div>
						<p class="info_profile"><?php echo $senha; ?></p>
				</div>
						
				
				

					<div class="clear"></div>

				<p id="tipuser_profile"> <?= $this->Usuario_model->valida_tipUser_num($tipuser)?></p>

				<a href="<?php echo base_url();?>index.php/Usuario/logout" class="btn btn-danger profile_botao">Logout</a>

				<a href="<?php echo site_url('Usuario/editUsuario');?>/<?php echo $cpf;?>" class="btn btn-success profile_botao">Editar Perfil</a>

				
			</div>

		</body>
	</html>