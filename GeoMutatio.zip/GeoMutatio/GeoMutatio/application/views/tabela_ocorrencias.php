<?php

include('header.php');

if ($this->session->userdata('usuario')) {

  $usuario = $this->session->userdata('usuario');

  if ($usuario['tipuser'] == 1) { 

    $ocorrencia['result'] = $this->Ocorrencia_model->getOcorrencias();
  
?>

<h1 style="margin-top: 7%; text-align: center"> Tabela de Ocorrências Cadastradas</h1>
<br>

<table class="table table-borderless" style="width: 70%; margin-left: 15%; margin-top: 3%;">
  <thead>
    <tr>
      <th scope="col">Código da Ocorrência</th>
      <th scope="col">Tipo de Ocorrência</th>
      <th scope="col">Data da Ocorrência</th>
      <th scope="col">Local </th>
      <th scope="col">Cadastrada por:</th>
    </tr>
  </thead>
  <tbody>

  	<?php foreach ($ocorrencia['result'] as $row) { ?>

    	<tr>
    	    <th scope="row"><?php echo $row->id_ocorrencia; ?></th>
    	    <td><?php echo $row->tipo_ocorrencia; ?></td>
          <td class="ellipsis"><?php echo $row->data_ocorrencia; ?></td>
    	    <td class="ellipsis"><?php echo $row->local; ?></td>
          <td><?php echo $row->cpf; ?></td>

          <td> <a href="<?php echo site_url('Ocorrencia/editOcorrencia');?>/<?php echo $row->id_ocorrencia;?>">Editar</a></td>
          <td> <p id="deletar_botao" style="cursor:pointer; color:#007bff;" >Deletar</p></td>
    	    <!-- Modal de login -->
          <div id="excluir_modal" class="modal">

              <!--Conteúdo do modal login -->
              <div class="modal-conteudo">

                <div class="modal-form" style="height:10em">
                  <p class="titulo-modal">Deseja mesmo excluir esta ocorrência?</p>

                  <a href="<?php echo site_url('Ocorrencia/deleteOcorrencia');?>/<?php echo $row->id_ocorrencia;?>" class="btn btnexcluir_conta">Excluir ocorrência</a>

                  <a href="<?php echo site_url('Redirect/tabela_ocorrencias')?>" class="btn btncancelar">Cancelar</a>	
                      
                  <span class="fechar"></span>
                </div>

              </div>

              </div>

              <script type="text/javascript">
                      // seleciona o modal
                    var modal = document.getElementById("excluir_modal");

                    // seleciona o botão que abre o modal
                    var btn = document.getElementById("deletar_botao");

                    // seleciona o elemento <span> que fecha o modal
                    var span = document.getElementsByClassName("fechar")[0];

                    // quando o usuário clicar no botão, abre o modal 
                    btn.onclick = function() {
                      modal.style.display = "block";
                    }

                    // quando o usuário clicar em <span> (x), fecha o modal
                    // não utilizada por enquanto
                    span.onclick = function() {
                      modal.style.display = "none";
                    }

                    // quando o usuário clicar em qualquer lugar fora da tela, fecha-o
                    window.onclick = function(event) {
                      if (event.target == modal) {
                      modal.style.display = "none";
                      }
                    }

                    </script>
    	</tr>

    <?php } ?>	

  </tbody>
</table>

<a  style="margin-left: 47vw; margin-top:2vw;" class="btn btn-success" href="<?php echo site_url('Redirect/ocorrencias')?>">Cadastrar Ocorrência</a>


<?php
  }else{
    redirect('/');
  }
}else{
  redirect('/');
}
?>