<!-- Footer -->
<footer class="page-footer font-small indigo" style="background-color: #769085; margin-top:18em;">

        <img class="logo" style="width:3vw; margin-left: 48vw; margin-top:2em; " src="<?= base_url();?>/assets/imagens/icons/logo.png">
    
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3" style="color:black;">© 2019 Copyright:
    <a href="/GeoMutatio/GeoMutatio" style="color:white;"> GeoMutatio.com</a>

  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->