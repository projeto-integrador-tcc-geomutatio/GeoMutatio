<?php

include('header.php');

if ($this->session->userdata('usuario')) {

  $usuario = $this->session->userdata('usuario');

  if ($usuario['tipuser'] == 1 OR 2) { 

    $noticia['result'] = $this->Noticia_model->getNoticias();
  
?>

<h1 style="margin-top: 7%; text-align: center"> Tabela de notícias Cadastradas</h1>
<br>

<table class="table table-borderless" style="width: 70%; margin-left: 15%; margin-top: 3%;">
  <thead>
    <tr>
      <th scope="col">Código da Noticia</th>
      <th scope="col">Titulo da Notícia</th>
      <th scope="col">Subtítulo da Notícia</th>
      <th scope="col">Descrição da Noticia</th>
      <th scope="col">Data da Notícia</th>
      <th scope="col">Foto da Notícia</th>
      <th scope="col">Publicado por:</th>
    </tr>
  </thead>
  <tbody>

  	<?php foreach ($noticia['result'] as $row) { ?>

    	<tr>
    	    <th scope="row"><?php echo $row->codnoticia; ?></th>
    	    <td><?php echo $row->titulo_noticia; ?></td>
          <td class="ellipsis"><?php echo $row->subtitulo_noticia; ?></td>
    	    <td class="ellipsis"><?php echo $row->desc_noticia; ?></td>
          <td><?php echo $row->data_noticia; ?></td>
          <td><?php echo strlen($row->foto_noticia); ?></td>
          <td><?php echo $row->cpf; ?> </td>

    	    <td> <a href="<?php echo site_url('Noticia/editNoticia');?>/<?php echo $row->codnoticia;?>">Editar</a></td>
    	    <td> <p id="deletar_botao" style="cursor:pointer; color:#007bff;" >Deletar</p></td>
          <!-- Modal de login -->
          <div id="excluir_modal" class="modal">

              <!--Conteúdo do modal login -->
              <div class="modal-conteudo">

                <div class="modal-form" style="height:10em">
                  <p class="titulo-modal">Deseja mesmo excluir esta notícia?</p>

                  <a href="<?php echo site_url('Noticia/deleteNoticia');?>/<?php echo $row->codnoticia;?>" class="btn btnexcluir_conta">Excluir notícia</a>

                  <a href="<?php echo site_url('Redirect/tabela_noticias')?>" class="btn btncancelar">Cancelar</a>	
                      
                  <span class="fechar"></span>
                </div>

              </div>

              </div>

              <script type="text/javascript">
                      // seleciona o modal
                    var modal = document.getElementById("excluir_modal");

                    // seleciona o botão que abre o modal
                    var btn = document.getElementById("deletar_botao");

                    // seleciona o elemento <span> que fecha o modal
                    var span = document.getElementsByClassName("fechar")[0];

                    // quando o usuário clicar no botão, abre o modal 
                    btn.onclick = function() {
                      modal.style.display = "block";
                    }

                    // quando o usuário clicar em <span> (x), fecha o modal
                    // não utilizada por enquanto
                    span.onclick = function() {
                      modal.style.display = "none";
                    }

                    // quando o usuário clicar em qualquer lugar fora da tela, fecha-o
                    window.onclick = function(event) {
                      if (event.target == modal) {
                      modal.style.display = "none";
                      }
                    }

                    </script>
    	</tr>

    <?php } ?>	

  </tbody>
</table>

<a  style="margin-left: 47vw; margin-top:5vw;" class="btn btn-success" href="<?php echo site_url('Redirect/cad_noticia')?>">Cadastrar noticia</a>


<?php
  }else{
    redirect('/');
  }
}else{
  redirect('/');
}
?>