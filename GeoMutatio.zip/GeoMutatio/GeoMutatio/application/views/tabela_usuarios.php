<?php

include('header.php');

if ($this->session->userdata('usuario')) {

  $usuario = $this->session->userdata('usuario');

  if ($usuario['tipuser'] == 1) { 

    $usuario['result'] = $this->Usuario_model->getUsuarios();
  
?>

<h1 style="margin-top: 7%; text-align: center;"> Tabela de Usuários Cadastrados</h1>


<table class="table table-borderless" style="width: 70%; margin-left: 15%; margin-top: 3%;">
  <thead>
    <tr>
      <th scope="col">CPF</th>
      <th scope="col">Nome</th>
      <th scope="col">E-mail</th>
      <th scope="col">Senha</th>
      <th scope="col">Data de Nascimento</th>
      <th scope="col">Tipo de Usuário</th>
    </tr>
  </thead>
  <tbody>

  	<?php foreach ($usuario['result'] as $row) { 

      $cpf = $this->Usuario_model->valida_cpf($row->cpf);
     // $tipuser = $this->Usuario_model->valida_tipUser_num($row->tipuser);
     // $email = $this->Usuario_model->converte_email($row->email);


      ?>


    	<tr>
    	    <th scope="row"><?php echo $cpf; ?></th>
    	    <td><?php echo $row->nome; ?></td>
    	    <td><?php echo $row->email; ?></td>
    	    <td><?php echo $row->senha; ?></td>
    	    <td><?php echo $row->datanasc; ?></td>
          <td><?php echo $row->tipuser; ?></td>
    	    <td> <a href="<?php echo site_url('Usuario/editUsuario');?>/<?php echo $row->cpf;?>">Editar</a></td>
          <td> <p id="deletar_botao" style="cursor:pointer; color:#007bff;" >Deletar</p></td>
          <!-- Modal de login -->
          <div id="excluir_modal" class="modal">

              <!--Conteúdo do modal login -->
              <div class="modal-conteudo">

                <div class="modal-form" style="height:10em">
                  <p class="titulo-modal">Deseja mesmo excluir esta conta?</p>

                  <a href="<?php echo site_url('Usuario/deleteUsuario');?>/<?php echo $cpf;?>" class="btn btnexcluir_conta">Excluir perfil</a>

                  <a href="<?php echo base_url();?>index.php/Usuario/tabela_usuarios" class="btn btncancelar">Cancelar</a>	
                      
                  <span class="fechar"></span>
                </div>

              </div>

              </div>

              <script type="text/javascript">
                      // seleciona o modal
                    var modal = document.getElementById("excluir_modal");

                    // seleciona o botão que abre o modal
                    var btn = document.getElementById("deletar_botao");

                    // seleciona o elemento <span> que fecha o modal
                    var span = document.getElementsByClassName("fechar")[0];

                    // quando o usuário clicar no botão, abre o modal 
                    btn.onclick = function() {
                      modal.style.display = "block";
                    }

                    // quando o usuário clicar em <span> (x), fecha o modal
                    // não utilizada por enquanto
                    span.onclick = function() {
                      modal.style.display = "none";
                    }

                    // quando o usuário clicar em qualquer lugar fora da tela, fecha-o
                    window.onclick = function(event) {
                      if (event.target == modal) {
                      modal.style.display = "none";
                      }
                    }

                    </script>
            </tr>

    <?php } ?>	

  </tbody>
</table>

<?php
  }else{
    redirect('/');
  }
}else{
  redirect('/');
}

//print_r($usuario);
?>