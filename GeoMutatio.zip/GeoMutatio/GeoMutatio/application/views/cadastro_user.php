<?php include('header.php'); ?>

<form class="form-horizontal" style="margin-left: 5%; margin-top: 7%;" action="<?php echo site_url('Usuario/createUsuario')?>"  method="POST">
  <fieldset>
    <div id="legend">
      <h2 style="margin-left: 14%;">Cadastro<h2>
    </div>
    <div class="container" style="margin-top: 3%;">

      <input type="hidden" name="tipuser" value="0">
      <!-- Username -->
      <label class="control-label"  for="nome">Nome</label>
      <div class="controls">
        <input type="text" id="nome" name="nome" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- E-mail -->
      <label class="control-label" for="email">E-mail</label>
      <div class="controls">
        <input type="text" id="email" name="email" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Username -->
      <label class="control-label"  for="cpf">CPF</label>
      <div class="controls">
        <input type="text" id="cpf" name="cpf" placeholder="" class="form-control">
      </div>
    </div>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Password-->
      <label class="control-label" for="senha">Senha</label>
      <div class="controls">
        <input type="password" id="senha" name="senha" placeholder="" class="form-control">
      </div>
    </div>

    <div class="container" style="margin-top: 1%;">
      <!-- Password -->
      <label class="control-label"  for="datanasc">Data de Nascimento</label>
      <div class="controls">
        <input type="date" id="datanasc" name="datanasc" placeholder="" class="form-control">
      </div>
    </div>
    <br>
 
    <div class="container" style="margin-top: 1%;">
      <!-- Button -->
      <div class="controls">
        <button class="btn btn-success">Cadastrar</button>
      </div>
    </div>
  </fieldset>
</form>
