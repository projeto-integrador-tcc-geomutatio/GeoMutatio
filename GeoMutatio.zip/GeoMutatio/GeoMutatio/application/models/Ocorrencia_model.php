<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ocorrencia_model extends CI_Model{

	public function __construct(){

		$this->load->database();

	}



	function criarOcorrencia(){

		$local = $this->Ocorrencia_model->validaLatLng($this->input->post('local'));

		$ocorrencia = $this->input->post('tipo_ocorrencia');

		if ($ocorrencia == 'buraco') {

			$nome = 'Buraco';
			$imagem = 'p_buraco.png';
			
		}elseif ($ocorrencia == 'alagamento') {

			$nome = 'Alagamento';
			$imagem = 'p_alagamento.png';
			
		}elseif ($ocorrencia == 'deslizamento') {

			$nome = 'Deslizamento de Terra';
			$imagem = 'p_deslizamento.png';
			
		}elseif ($ocorrencia == 'arvore') {

			$nome = 'Árvore Caída';
			$imagem = 'p_arvore.png';
			
		}else {
			$nome = 'ocorrencia';
			$imagem = 'default.png';
		}


		$ocorrencia = array(

			'nome_ocorrencia' => $nome,
			'tipo_ocorrencia' => $this->input->post('tipo_ocorrencia'),
			'data_ocorrencia' => $this->input->post('data_ocorrencia'),
			'qtd_curtidas' => 0,
			'local' => $local,
			'cpf' => $this->input->post('cpf'),
			'imagem_ocorrencia' => $imagem

		);

		$this->db->insert('ocorrencia', $ocorrencia);
	}

	function getOcorrencias()
	{
		$query = $this->db->query('SELECT * FROM ocorrencia');
		return $query->result();
	}


	function getOcorrencia($id_ocorrencia)
	{
		$query = $this->db->query('SELECT * FROM ocorrencia WHERE `id_ocorrencia` ='.$id_ocorrencia);
		return $query->row();
	}

	function getCurtidas($id_ocorrencia)
	{
		$query = $this->db->query('SELECT `curtidas` FROM ocorrencia WHERE `id_ocorrencia` ='.$id_ocorrencia);
		return $query->row();
	}

	function atualizarOcorrencia($id_ocorrencia)
	{

		$ocorrencia = $this->input->post('tipo_ocorrencia');

		if ($ocorrencia == 'buraco') {

			$nome = 'Buraco';
			$imagem = 'buraco.png';
			
		}elseif ($ocorrencia == 'alagamento') {

			$nome = 'Alagamento';
			$imagem = 'alagamento.png';
			
		}elseif ($ocorrencia == 'deslizamento') {

			$nome = 'Deslizamento de Terra';
			$imagem = 'deslizamento.png';
			
		}elseif ($ocorrencia == 'arvore') {

			$nome = 'Árvore Caída';
			$imagem = 'deslizamento.png';
			
		}else {
			$nome = 'ocorrencia';
			$imagem = 'default.png';
		}


			$ocorrencia = array(
			
			'nome_ocorrencia' => $nome,
			'tipo_ocorrencia' => $this->input->post('tipo_ocorrencia'),
			'data_ocorrencia' => $this->input->post('data_ocorrencia'),
			'qtd_curtidas' => getCurtidas($id_ocorrencia),
			'cpf' => $this->input->post('cpf'),
			'imagem_ocorrencia' => $imagem
			
		);
		$this->db->where('id_ocorrencia', $id_ocorrencia);
		$this->db->update('ocorrencia', $ocorrencia);
	}

		function deletarOcorrencia($id_ocorrencia)
	{
		$this->db->where('id_ocorrencia', $id_ocorrencia);
		$this->db->delete('ocorrencia');
	}

		function lat_lng_array($local){

			$localFrag1 = explode("(", $local);
			$localFrag2 = explode(")", $localFrag1[1]);
			$localFrag3 = explode(",", $localFrag2[0]);

			$latLng['lat'] = $localFrag3[0];
			$latLng['lng'] = $localFrag3[1];

			return $latLng;

		}

		function validaLatLng($local){

			$localFrag1 = explode("(", $local);
			$localFrag2 = explode(")", $localFrag1[1]);
			
			$latLng = $localFrag2[0];

			return $latLng;

		}


		function upVote($id_ocorrencia){

			$ocorrencia = $this->Ocorrencia_model->getOcorrencia($id_ocorrencia);

			$ocorrenciaCurtida = $ocorrencia->qtd_curtidas;
			$ocorrenciaCurtida += 1;

			$ocorrencia->qtd_curtidas = $ocorrenciaCurtida;

			$this->db->insert('ocorrencia', $ocorrencia);

			;

		}




	}

?>


