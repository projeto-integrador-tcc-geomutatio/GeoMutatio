<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Noticia_model extends CI_Model{

//Funções de consulta

	function getNoticias()
	{
		$query = $this->db->query('SELECT * FROM noticia');
		return $query->result();
	}

	function getNoticia($codnoticia)
	{
		$query = $this->db->query('SELECT * FROM noticia WHERE `codnoticia` ='.$codnoticia);
		return $query->row();
	}

//Funções do CRUD

	function criarNoticia()
	{
		$noticia = array(
			'titulo_noticia' => $this->input->post('titulo_noticia'),
			'subtitulo_noticia' => $this->input->post('subtitulo_noticia'),
			'desc_noticia' => $this->input->post('desc_noticia'),
			'data_noticia' => $this->input->post('data_noticia'),
			'foto_noticia' => $this->input->post('foto_noticia'),
			'cpf' => $this->input->post('cpf')
		);
		$this->db->insert('noticia', $noticia);
	}

	function atualizarNoticia($codnoticia)
	{
		$noticia = array(
			'titulo_noticia' => $this->input->post('titulo_noticia'),
			'subtitulo_noticia' => $this->input->post('subtitulo_noticia'),
			'desc_noticia' => $this->input->post('desc_noticia'),
            'data_noticia' => $this->input->post('data_noticia'),
			'foto_noticia' => $this->input->post('foto_noticia'),
			'cpf' => $this->input->post('cpf')
		);
		$this->db->where('codnoticia', $codnoticia);
		$this->db->update('noticia', $noticia);
	}

	function deletarNoticia($codnoticia)
	{
		$this->db->where('codnoticia', $codnoticia);
		$this->db->delete('noticia');
	}


}
