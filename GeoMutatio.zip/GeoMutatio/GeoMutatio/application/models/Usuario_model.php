<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}


//Funções do CRUD

	function criarUsuario($file){

		$cpf = ($this->Usuario_model->valida_cpf($this->input->post('cpf')));
		//$email = ($this->Usuario_model->converte_email($this->input->post('email')));

		$usuario = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $cpf,
			'tipuser' => $this->input->post('tipuser'),
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
		);

		$target_dir = BASEPATH."../assets/imagens/usuarios/";
$target_file = $target_dir . basename($file["foto_perfil"]["name"]);


    if (move_uploaded_file($file["foto_perfil"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $file["foto_perfil"]["name"]). " has been uploaded.";

        $nome_antigo = $target_dir.basename($file["foto_perfil"]["name"]);
        $nome_novo = $target_dir.$cpf;

        rename($nome_antigo, $nome_novo);



    } else {
        echo "Sorry, there was an error uploading your file.";
    }


			$this->db->insert('usuario', $usuario);
	
	}	

	function getUsuarios()
	{
		$query = $this->db->query('SELECT * FROM usuario');
		return $query->result();
	}


	function getUsuario($cpf)
	{
		$query = $this->db->query('SELECT * FROM usuario WHERE `cpf` ='.$cpf);
		return $query->row();
	}

	/*function getEmail($email)
	{

		$query = $this->db->query('SELECT * FROM usuario WHERE `email` ='.$email);
		return $query->row();
	}*/

	function atualizarUsuario($cpf)
	{

		$cpf = ($this->Usuario_model->valida_cpf($this->input->post('cpf')));
		//$tipuser = ($this->Usuario_model->valida_tipUser_num($this->input->post('tipuser')));

		//$email = ($this->Usuario_model->converte_email($this->input->post('email')));

		$usuario = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $cpf,
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
			'tipuser' =>  $this->input->post('tipuser'),
		);
		$this->db->where('cpf', $cpf);
		$this->db->update('usuario', $usuario);
	}

	function deletarUsuario($cpf)
	{
		$this->db->where('cpf', $cpf);
		$this->db->delete('usuario');
	}

	 function valida_cpf($cpf){

		if ($cpf[3] == '.') {
			
		$cpf_ponto = explode('.', $cpf);
		$cpf_traco = implode('', $cpf_ponto);
		$cpf_semTraco = explode('-', $cpf_traco);
		$cpf_final = implode('', $cpf_semTraco);
			
		}else{

			$array_cpf[0] = [$cpf[0], $cpf[1], $cpf[2], "."];
			$array_final[0] = implode('', $array_cpf[0]);

			$array_cpf[1] = [$cpf[3], $cpf[4], $cpf[5], "."];
			$array_final[1] = implode('', $array_cpf[1]);

			$array_cpf[2] = [$cpf[6], $cpf[7], $cpf[8], "-"];
			$array_final[2] = implode('', $array_cpf[2]);

			$array_cpf[3] = [$cpf[9], $cpf[10]];
			$array_final[3] = implode('', $array_cpf[3]);

			$cpf_final = implode('', $array_final);

		
		}

		return $cpf_final;
	}

	function valida_tipUser_num($tipuser){

		if ($tipuser == 0) {

			$tipUserFinal = 'Usuário Comum';
			return $tipUserFinal;

		}elseif ($tipuser == 1) {

			$tipUserFinal = 'Administrador';
			return $tipUserFinal;

		}elseif ($tipuser == 2) {

			$tipUserFinal = 'Autor';
			return $tipUserFinal;

		}

	}

	function valida_tipUser_nome($tipuser){

		if ($tipuser == 'Usuário Comum') {

				$tipUserFinal = 0;
				return $tipUserFinal;

			}elseif ($tipuser == 'Administrador') {

				$tipUserFinal = 1;
				return $tipUserFinal;

			}elseif ($tipuser == 'Autor') {

				$tipUserFinal = 2;
				return $tipUserFinal;

			}
	}
/*
function converte_email($email_par){

		$email = str_split($email_par, 1);

		foreach ($email as $pos => $letra) {
			if ($letra == '@') {

				$email_sem_arroba = explode('@', $email_par);
				$email_final = implode(',', $email_sem_arroba);

				return $email_final;
			
			}elseif ($letra == ',') {

				$email_sem_virgula = explode(',', $email_par);
				$email_final = implode('@', $email_sem_virgula);

				return $email_final;
				
			}
		}

	}
	*/	
		function valida_email($email){
			
			$contador = 0;

			foreach ($email as $pos => $letra) {

				if ($letra == '@') {

					$contador++;
					
				} 
			}

			if ($contador == 1) {
				echo "email valido";
			}else{
				echo "email invaldo";
			}

		}


		
	
	

//Funções do Login

	function UsuarioLogin($email,$senha){
		$usuario = $this->db->get_where('usuario', array('email'=>$email,'senha'=>$senha));
		return $usuario->row_array();
	}

	
}