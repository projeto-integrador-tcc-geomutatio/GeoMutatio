<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}


//Funções do CRUD

	function criarUsuario()
	{
		$usuario = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $this->input->post('cpf'),
			'tipuser' => $this->input->post('tipuser'),
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
		);
		$this->db->insert('usuario', $usuario);
	}	

	function getUsuarios()
	{
		$query = $this->db->query('SELECT * FROM usuario');
		return $query->result();
	}


	function getUsuario($cpf)
	{
		$query = $this->db->query('SELECT * FROM usuario WHERE `cpf` ='.$cpf);
		return $query->row();
	}

	function atualizarUsuario($cpf)
	{
		$usuario = array(
			'nome' => $this->input->post('nome'),
			'email' => $this->input->post('email'),
			'cpf' => $this->input->post('cpf'),
			'senha' => $this->input->post('senha'),
			'datanasc' => $this->input->post('datanasc'),
			'tipuser' => $this->input->post('tipuser'),
		);
		$this->db->where('cpf', $cpf);
		$this->db->update('usuario', $usuario);
	}

	function deletarUsuario($cpf)
	{
		$this->db->where('cpf', $cpf);
		$this->db->delete('usuario');
	}


//Funções do Login

	function UsuarioLogin($email,$senha){
		$usuario = $this->db->get_where('usuario', array('email'=>$email,'senha'=>$senha));
		return $usuario->row_array();
	}
}

	