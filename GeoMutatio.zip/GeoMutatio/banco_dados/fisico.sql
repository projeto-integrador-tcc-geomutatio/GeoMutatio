-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE noticia (
data_noticia date,
hora_noticia varchar(5),
desc_noticia varchar(1350),
titulo_noticia varchar(50),
codnoticia varchar(5) PRIMARY KEY,
codusuario varchar(14)
);

CREATE TABLE uf (
iduf int PRIMARY KEY,
nomuf varchar(80)
);

CREATE TABLE usuario (
nome varchar(80),
email varchar(80),
cpf varchar(14) PRIMARY KEY,
tipuser boolean,
datanasc date,
senha varchar(14),
idlogradouro int
);

CREATE TABLE ocorrencia (
codocorrencia varchar(5) PRIMARY KEY,
titulo_ocorrencia varchar(50),
hora_ocorrencia varchar(5),
desc_ocorrencia varchar(1350),
logradouro_ocorrencia varchar(50),
data_ocorrencia date,
cpf varchar(14),
FOREIGN KEY(cpf) REFERENCES usuario (cpf)
);

CREATE TABLE logradouro (
nomlogradouro varchar(80),
cep varchar(11),
idlogradouro int PRIMARY KEY
);

CREATE TABLE tipuser (
desctipuser varchar(80),
idtipuser int PRIMARY KEY
);

CREATE TABLE bairro (
nombairro varchar(80),
idbairro int PRIMARY KEY,
idcidade int
);

CREATE TABLE cidade (
nomcidade varchar(80),
idcidade int PRIMARY KEY,
iduf int,
FOREIGN KEY(iduf) REFERENCES uf (iduf)
);

CREATE TABLE not_log (
codnoticia varchar(5),
idlogradouro int,
FOREIGN KEY(codnoticia) REFERENCES noticia (codnoticia),
FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro)
);

CREATE TABLE oc_log (
codocorrencia varchar(5),
idlogradouro int,
FOREIGN KEY(codocorrencia) REFERENCES ocorrencia (codocorrencia),
FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro)
);

CREATE TABLE user_tipuser (
cpf varchar(14),
idtipuser int,
FOREIGN KEY(cpf) REFERENCES usuario (cpf),
FOREIGN KEY(idtipuser) REFERENCES tipuser (idtipuser)
);

CREATE TABLE log_bairro (
idbairro int,
idlogradouro int,
FOREIGN KEY(idbairro) REFERENCES bairro (idbairro),
FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro)
);

ALTER TABLE noticia ADD FOREIGN KEY(cpf) REFERENCES usuario (cpf);
ALTER TABLE usuario ADD FOREIGN KEY(idlogradouro) REFERENCES logradouro (idlogradouro);
ALTER TABLE bairro ADD FOREIGN KEY(idcidade) REFERENCES cidade (idcidade);
