-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 28-Nov-2019 às 12:03
-- Versão do servidor: 5.7.24-0ubuntu0.18.04.1
-- PHP Version: 7.2.13-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geomutatio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtidas`
--

CREATE TABLE `curtidas` (
  `id_curtida` int(12) NOT NULL,
  `usuario_cpf` varchar(14) NOT NULL,
  `ocorrencia_id` varchar(10) NOT NULL,
  `avaliacao` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `curtidas`
--

INSERT INTO `curtidas` (`id_curtida`, `usuario_cpf`, `ocorrencia_id`, `avaliacao`) VALUES
(191, '00000000000', '105', 'like'),
(192, '00000000000', '108', 'like'),
(193, '00000000000', '106', 'like'),
(194, '22222222222', '105', 'like'),
(195, '22222222222', '108', 'like'),
(196, '22222222222', '106', 'like'),
(197, '11111111111', '105', 'like'),
(198, '11111111111', '108', 'like'),
(199, '11111111111', '106', 'like'),
(200, '12093712371', '105', 'like'),
(201, '12093712371', '108', 'like'),
(202, '12093712371', '106', 'like'),
(203, '10380128301', '105', 'like'),
(204, '10380128301', '108', 'like'),
(205, '10380128301', '107', 'deslike'),
(207, '12093712371', '107', 'deslike'),
(208, '22222222222', '107', 'deslike'),
(209, '11111111111', '107', 'deslike');

-- --------------------------------------------------------

--
-- Estrutura da tabela `familia`
--

CREATE TABLE `familia` (
  `nome_fam` varchar(30) DEFAULT NULL,
  `id_familia` int(10) NOT NULL,
  `pessoas_fam` varchar(255) DEFAULT NULL,
  `recursos_nec` varchar(255) NOT NULL,
  `telefone_fam` varchar(30) NOT NULL,
  `endereco_fam` varchar(255) NOT NULL,
  `foto_familia` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `familia`
--

INSERT INTO `familia` (`nome_fam`, `id_familia`, `pessoas_fam`, `recursos_nec`, `telefone_fam`, `endereco_fam`, `foto_familia`) VALUES
('Oliveira', 20, 'Filipe, Jonas. Roberto, Karolina', 'Pão, Dinheiro, Abrigo de animais', '', '', ''),
('Rolinete', 21, 'Alex, Greice, Golias', 'Um upload de imagens funcional :D', '(12)34123-3444', 'rua ulisses ', 0x526f6c696e657465),
('Oliveirasadasd', 22, 'João, roberto', 'Pão, Dinheiro, Abrigo de animaisaaaa', '(13)43534-5345', 'rua pinhaiosdssdf', 0x4f6c697665697261736164617364),
('Garcia', 23, 'Pedrinho, Geraldo, Jones', 'Leite, Trigo, Fermento', '(43)45334-5454', 'Rua marechal joinvas', 0x476172636961),
('aaaaaaaaaaaaaaaaaaaateste', 24, 'Filipe, Jonas. Roberto, Karolinaaaaa', 'Pão, Dinheiro, Abrigo de animaisaaaaaaaa', '(23)32439-0404', 'Rua marechal joinvasaaaaaa', 0x61616161616161616161616161616161616161617465737465),
('agoravai', 25, 'Filipe, Jonas. Roberto, Karolinaaadddd', 'Um upload de imagens funcional :Dsssss', '(12)35455-5555', 'rua pinhaiosdssdf', 0x61676f7261766169);

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticia`
--

CREATE TABLE `noticia` (
  `codnoticia` int(5) NOT NULL,
  `titulo_noticia` varchar(500) DEFAULT 'NULL',
  `subtitulo_noticia` varchar(1350) NOT NULL,
  `desc_noticia` mediumtext,
  `data_noticia` date DEFAULT NULL,
  `foto_noticia` text,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `noticia`
--

INSERT INTO `noticia` (`codnoticia`, `titulo_noticia`, `subtitulo_noticia`, `desc_noticia`, `data_noticia`, `foto_noticia`, `cpf`) VALUES
(52, 'Moradores escorregam nas poças e batem a língua', 'Moradores sofrem com buracos na estradaMoradores sofrem com buracos na estrada', 'Moradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estradaMoradores sofrem com buracos na estrada', '2222-12-12', 'Moradores escorregam nas poças e batem a língua', '22222222222'),
(53, 'Teste de Upload de imagem para a notícia finalmente funciona', 'Teste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funciona', 'Teste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funcionaTeste de Upload de imagem para a notícia finalmente funciona', '0000-00-00', 'Teste de Upload de imagem para a notícia finalmente funciona', '22222222222'),
(54, 'Moradores escorregam nas poças e batem a cabeça', 'Moradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeça', 'Moradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeçaMoradores escorregam nas poças e batem a cabeça', '2200-12-12', 'Moradores escorregam nas poças e batem a cabeça', '11111111111'),
(55, 'sem imagem', '', 'ujdsa9djdsadsadssda', '2333-02-12', '', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencia`
--

CREATE TABLE `ocorrencia` (
  `id_ocorrencia` int(10) NOT NULL,
  `nome_ocorrencia` varchar(70) NOT NULL,
  `qtd_curtidas` int(4) DEFAULT '10',
  `tipo_ocorrencia` varchar(50) DEFAULT NULL,
  `data_ocorrencia` date DEFAULT NULL,
  `local` varchar(255) NOT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `imagem_ocorrencia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ocorrencia`
--

INSERT INTO `ocorrencia` (`id_ocorrencia`, `nome_ocorrencia`, `qtd_curtidas`, `tipo_ocorrencia`, `data_ocorrencia`, `local`, `cpf`, `imagem_ocorrencia`) VALUES
(101, 'Alagamento', 10, 'alagamento', '2019-11-28', '-26.279748, -48.905463', '11111111111', 'p_alagamento.png'),
(102, 'Deslizamento de Terra', 10, 'deslizamento', '2019-11-28', '-26.295998, -48.826611', '11111111111', 'p_deslizamento.png'),
(104, 'Buraco', 10, 'buraco', '2019-11-28', '-26.339571, -48.847446', '22222222222', 'p_buraco.png'),
(105, 'Árvore Caída', 15, 'arvore', '2019-11-28', '-26.300603, -48.831723', '00000000000', 'arvore.png'),
(106, 'Buraco', 14, 'buraco', '2019-11-28', '-26.252369, -48.869044', '00000000000', 'p_buraco.png'),
(107, 'Buraco', 6, 'buraco', '2019-11-28', '-26.364846, -48.829583', '00000000000', 'p_buraco.png'),
(108, 'Deslizamento de Terra', 15, 'deslizamento', '2019-11-28', '-26.288346, -48.862875', '00000000000', 'deslizamento.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `cpf` varchar(14) NOT NULL,
  `tipuser` tinyint(1) DEFAULT '0',
  `datanasc` date DEFAULT NULL,
  `senha` varchar(14) DEFAULT NULL,
  `foto_perfil` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nome`, `email`, `cpf`, `tipuser`, `datanasc`, `senha`, `foto_perfil`) VALUES
('Usuario Comum', 'usuario@usuario.com', '00000000000', 0, '2001-05-26', 'usuario', 'default.jpg'),
('Gustavo Baierski', 'gustavo@gustavo.com', '10380128301', 0, '2001-10-06', '123', '10380128301'),
('Administrador', 'admin@admin.com', '11111111111', 1, '2001-10-06', 'admin', 'default.jpg'),
('Ruan da Cunha ', 'ruan@ruan.com', '12093712371', 0, '2002-02-12', '123', '12093712371'),
('Autor', 'autor@autor.com', '22222222222', 2, '1988-05-02', 'autor', 'default.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `curtidas`
--
ALTER TABLE `curtidas`
  ADD PRIMARY KEY (`id_curtida`);

--
-- Indexes for table `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`id_familia`);

--
-- Indexes for table `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`codnoticia`) USING BTREE,
  ADD UNIQUE KEY `codnoticia` (`codnoticia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD PRIMARY KEY (`id_ocorrencia`),
  ADD KEY `cpf` (`cpf`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `curtidas`
--
ALTER TABLE `curtidas`
  MODIFY `id_curtida` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;
--
-- AUTO_INCREMENT for table `familia`
--
ALTER TABLE `familia`
  MODIFY `id_familia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `noticia`
--
ALTER TABLE `noticia`
  MODIFY `codnoticia` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `ocorrencia`
--
ALTER TABLE `ocorrencia`
  MODIFY `id_ocorrencia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD CONSTRAINT `ocorrencia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
