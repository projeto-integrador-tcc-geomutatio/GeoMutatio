-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25-Ago-2019 às 20:43
-- Versão do servidor: 10.3.16-MariaDB
-- versão do PHP: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `geomutatio`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairro`
--

CREATE TABLE `bairro` (
  `nombairro` varchar(80) DEFAULT NULL,
  `idbairro` int(11) NOT NULL,
  `idcidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `nomcidade` varchar(80) DEFAULT NULL,
  `idcidade` int(11) NOT NULL,
  `iduf` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `familia`
--

CREATE TABLE `familia` (
  `nome_fam` varchar(30) DEFAULT NULL,
  `qtd_pessoas` int(3) DEFAULT 1,
  `id_familia` int(10) NOT NULL,
  `pessoas_fam` varchar(255) DEFAULT NULL,
  `recursos_nec` varchar(255) NOT NULL,
  `foto_familia` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `familia`
--

INSERT INTO `familia` (`nome_fam`, `qtd_pessoas`, `id_familia`, `pessoas_fam`, `recursos_nec`, `foto_familia`) VALUES
('Silva', 1, 2, 'Zé', 'Almofada', ''),
('521', 2, 8, '2', '2', 0x7374796c652e637373);

-- --------------------------------------------------------

--
-- Estrutura da tabela `logradouro`
--

CREATE TABLE `logradouro` (
  `nomlogradouro` varchar(80) DEFAULT NULL,
  `cep` varchar(11) DEFAULT NULL,
  `idlogradouro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_bairro`
--

CREATE TABLE `log_bairro` (
  `idbairro` int(11) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticia`
--

CREATE TABLE `noticia` (
  `codnoticia` int(5) NOT NULL,
  `titulo_noticia` varchar(50) DEFAULT 'NULL',
  `desc_noticia` varchar(1350) DEFAULT 'NULL',
  `data_noticia` date DEFAULT NULL,
  `hora_noticia` varchar(5) DEFAULT NULL,
  `foto_noticia` blob NOT NULL,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `noticia`
--

INSERT INTO `noticia` (`codnoticia`, `titulo_noticia`, `desc_noticia`, `data_noticia`, `hora_noticia`, `foto_noticia`, `cpf`) VALUES
(12, 'Alagocorre', 'Você já passou por alguma rua com buracos em Joinville? Difícil que a resposta tenha sido “não”. Mas a prefeitura tem trabalhado para amenizar o problema.', '2019-08-07', NULL, 0x6465736c697a616d656e746f5f74657272612e6a7067, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencia`
--

CREATE TABLE `ocorrencia` (
  `codocorrencia` varchar(5) NOT NULL,
  `titulo_ocorrencia` varchar(50) DEFAULT NULL,
  `hora_ocorrencia` varchar(5) DEFAULT NULL,
  `desc_ocorrencia` varchar(1350) DEFAULT NULL,
  `logradouro_ocorrencia` varchar(50) DEFAULT NULL,
  `data_ocorrencia` date DEFAULT NULL,
  `cpf` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `oc_log`
--

CREATE TABLE `oc_log` (
  `codocorrencia` varchar(5) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipuser`
--

CREATE TABLE `tipuser` (
  `desctipuser` varchar(80) DEFAULT NULL,
  `idtipuser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipuser`
--

INSERT INTO `tipuser` (`desctipuser`, `idtipuser`) VALUES
('Usuário Comum', 0),
('Administrador', 1),
('Autor', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `uf`
--

CREATE TABLE `uf` (
  `iduf` int(11) NOT NULL,
  `nomuf` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_tipuser`
--

CREATE TABLE `user_tipuser` (
  `cpf` varchar(14) DEFAULT NULL,
  `idtipuser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `cpf` varchar(14) NOT NULL,
  `tipuser` tinyint(1) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `senha` varchar(14) DEFAULT NULL,
  `idlogradouro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nome`, `email`, `cpf`, `tipuser`, `datanasc`, `senha`, `idlogradouro`) VALUES
('Administrador', 'admin@gmail.com', '05158858942', 1, '2001-10-06', 'admin', NULL),
('Autor', 'autor@gmail.com', '14236987412', 2, '1988-05-02', 'autor', NULL),
('Usuario Comum', 'usuario@gmail.com', '23412412434', 0, '2001-05-26', 'usuario', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bairro`
--
ALTER TABLE `bairro`
  ADD PRIMARY KEY (`idbairro`),
  ADD KEY `idcidade` (`idcidade`);

--
-- Índices para tabela `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`idcidade`),
  ADD KEY `iduf` (`iduf`);

--
-- Índices para tabela `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`id_familia`);

--
-- Índices para tabela `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`idlogradouro`);

--
-- Índices para tabela `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD KEY `idbairro` (`idbairro`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Índices para tabela `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`codnoticia`) USING BTREE,
  ADD UNIQUE KEY `codnoticia` (`codnoticia`),
  ADD KEY `cpf` (`cpf`);

--
-- Índices para tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD PRIMARY KEY (`codocorrencia`),
  ADD KEY `cpf` (`cpf`);

--
-- Índices para tabela `oc_log`
--
ALTER TABLE `oc_log`
  ADD KEY `codocorrencia` (`codocorrencia`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- Índices para tabela `tipuser`
--
ALTER TABLE `tipuser`
  ADD PRIMARY KEY (`idtipuser`);

--
-- Índices para tabela `uf`
--
ALTER TABLE `uf`
  ADD PRIMARY KEY (`iduf`);

--
-- Índices para tabela `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD KEY `cpf` (`cpf`),
  ADD KEY `idtipuser` (`idtipuser`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`),
  ADD KEY `idlogradouro` (`idlogradouro`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `familia`
--
ALTER TABLE `familia`
  MODIFY `id_familia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `noticia`
--
ALTER TABLE `noticia`
  MODIFY `codnoticia` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `bairro`
--
ALTER TABLE `bairro`
  ADD CONSTRAINT `bairro_ibfk_1` FOREIGN KEY (`idcidade`) REFERENCES `cidade` (`idcidade`);

--
-- Limitadores para a tabela `cidade`
--
ALTER TABLE `cidade`
  ADD CONSTRAINT `cidade_ibfk_1` FOREIGN KEY (`iduf`) REFERENCES `uf` (`iduf`);

--
-- Limitadores para a tabela `log_bairro`
--
ALTER TABLE `log_bairro`
  ADD CONSTRAINT `log_bairro_ibfk_1` FOREIGN KEY (`idbairro`) REFERENCES `bairro` (`idbairro`),
  ADD CONSTRAINT `log_bairro_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `noticia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `ocorrencia`
--
ALTER TABLE `ocorrencia`
  ADD CONSTRAINT `ocorrencia_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`);

--
-- Limitadores para a tabela `oc_log`
--
ALTER TABLE `oc_log`
  ADD CONSTRAINT `oc_log_ibfk_1` FOREIGN KEY (`codocorrencia`) REFERENCES `ocorrencia` (`codocorrencia`),
  ADD CONSTRAINT `oc_log_ibfk_2` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);

--
-- Limitadores para a tabela `user_tipuser`
--
ALTER TABLE `user_tipuser`
  ADD CONSTRAINT `user_tipuser_ibfk_1` FOREIGN KEY (`cpf`) REFERENCES `usuario` (`cpf`),
  ADD CONSTRAINT `user_tipuser_ibfk_2` FOREIGN KEY (`idtipuser`) REFERENCES `tipuser` (`idtipuser`);

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`idlogradouro`) REFERENCES `logradouro` (`idlogradouro`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
