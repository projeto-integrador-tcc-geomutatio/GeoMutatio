insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('05158858942','Administrador', 'admin@gmail.com','2001-10-06', 'admin',1);
insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('14236987412','Autor', 'autor@gmail.com','1988-05-02', 'autor',2);
insert into usuario (cpf, nome, email, datanasc, senha, tipuser) values ('23412412434','Usuario Comum', 'usuario@gmail.com','2001-05-26', 'usuario',0);
