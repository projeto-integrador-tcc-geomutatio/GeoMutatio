<?php

include('header.php');

//if ($this->session->userdata('usuario')) {

  //if ($usuario['tipuser'] == 1 OR 2) { 

  $familia['result'] = $this->Familia_model->getFamilias();
  
?>
<h1 style="margin-top: 5%; text-align: center;"> Famílias</h1>
<?php foreach ($familia['result'] as $row) { ?>

		<div class="card" style="width: 18rem; margin-left:4%; margin-top:4%; float:left;">
			<a href="<?php echo site_url('Redirect/familia')?>/<?= $row->id_familia ?>">
				<img class="card-img-top" src="<?= base_url();?>/assets/imagens/familias/familia.jpg" alt="Card image cap">
			</a>	
			<div class="card-body">
				<h5 class="card-title"> Familia <?php echo $row->nome_fam; ?></h5>
				<p class="card-text">Composta por: <?php echo $row->pessoas_fam; ?> </p>
				<p class="card-text">Recursos necessitados: <?php echo $row->recursos_nec; ?> </p>
			</div>
    	</div>

<?php } 	
	if ($this->session->userdata('usuario')) {

		$usuario = $this->session->userdata('usuario');

		if ($usuario['tipuser'] == 1 or $usuario['tipuser'] == 2) { ?>

			<a  style="margin-top: 30%; float: left;" class="btn btn-success" href="<?php echo site_url('Redirect/cad_familia')?>">Cadastrar familia</a>
		
		<?php 									
		}else{ 	}
		}else{  }	?>