Grocery CRUD
=============
Grocery CRUD is a PHP and Codeigniter Framework library that creates a full functional CRUD system without the need to customise JavaScript or CSS.

For more information, visit http://www.grocerycrud.com